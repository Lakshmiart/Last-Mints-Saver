/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import fs from 'fs';
import AdmZip from 'adm-zip';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Lazy initialization of GoogleGenAI
let aiClient: GoogleGenAI | null = null;

function getAIClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  // If the apiKey is the placeholder or is missing, do not initialize to avoid crashing.
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY' || apiKey.trim() === '') {
    return null;
  }
  if (!aiClient) {
    try {
      aiClient = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });
    } catch (err) {
      console.error('Failed to initialize GoogleGenAI client:', err);
      return null;
    }
  }
  return aiClient;
}

// ---------------------------------------------------------
// Heuristic Fallback Logic (if Gemini API key is missing)
// ---------------------------------------------------------
interface ClassificationResult {
  category: 'VERY_URGENT' | 'URGENT' | 'DAY_END';
  consequence: string;
  actionSuggestion: string;
}

function runHeuristicClassifier(name: string, deadline: string): ClassificationResult {
  const lower = name.toLowerCase();
  
  // Rule-based classification
  if (
    lower.includes('interview') ||
    lower.includes('meeting') ||
    lower.includes('call') ||
    lower.includes('client') ||
    lower.includes('exam') ||
    lower.includes('test') ||
    lower.includes('bill') ||
    lower.includes('rent') ||
    lower.includes('tax') ||
    lower.includes('flight') ||
    lower.includes('deadline') ||
    lower.includes('presentation')
  ) {
    return {
      category: 'VERY_URGENT',
      consequence: 'Missing this will result in immediate negative external consequence (lost opportunity, late fees, or broken commitments).',
      actionSuggestion: `Block out 30 minutes immediately before ${deadline} to prep, and set a hard alarm.`,
    };
  } else if (
    lower.includes('homework') ||
    lower.includes('assignment') ||
    lower.includes('project') ||
    lower.includes('study') ||
    lower.includes('gym') ||
    lower.includes('workout') ||
    lower.includes('run') ||
    lower.includes('submit') ||
    lower.includes('report') ||
    lower.includes('clean') ||
    lower.includes('laundry')
  ) {
    return {
      category: 'URGENT',
      consequence: 'Important for personal or academic progress, but has some visual flexibility without immediate financial or social penalty.',
      actionSuggestion: 'Identify a clear 1-hour block this afternoon and start with the simplest 5-minute step.',
    };
  } else {
    return {
      category: 'DAY_END',
      consequence: 'Low immediate time-sensitivity. Can comfortably slide to the evening or carry over if high-priority items take longer.',
      actionSuggestion: 'Consolidate this with other low-energy admin tasks at the end of your day.',
    };
  }
}

function runHeuristicNudge(task: any, checkInType: string): string {
  const { name, consequence, actionSuggestion } = task;
  if (checkInType === '12:00 PM') {
    return `Quick check — you've got "${name}" on your radar for today. It's a lower urgency item, so it's a perfect time to knock it out now before things get busier!`;
  } else if (checkInType === '3:00 PM') {
    return `Afternoon check-in: "${name}" is still pending. Since this is an important item, do you want to start now, or block out a direct slot in your calendar?`;
  } else if (checkInType === '6:00 PM') {
    return `Heads up — "${name}" is Very Urgent. ${consequence} This is your last clear window before the end of the day. Want to start by just doing the very first 5-minute action?`;
  } else {
    return `🔔 Final alarm: "${name}" is due by the end of the day and is still marked incomplete. Let's tackle it now!`;
  }
}

// ---------------------------------------------------------
// API Route Handlers
// ---------------------------------------------------------

// Check AI status
app.get('/api/ai-status', (req, res) => {
  const client = getAIClient();
  res.json({
    active: client !== null,
    model: 'gemini-3.5-flash',
    info: client !== null ? 'Gemini 3.5 Active' : 'High-fidelity Rule-based Heuristic Local Mode (No Gemini Key)',
  });
});

// Download app source code bundle as a ZIP archive
app.get('/api/download-app', (req, res) => {
  try {
    const zip = new AdmZip();
    const rootDir = process.cwd();

    const addFolderToZip = (localDir: string, zipDir: string) => {
      const entries = fs.readdirSync(localDir, { withFileTypes: true });
      for (const entry of entries) {
        const name = entry.name;
        // Exclude big or temporary folders/files
        if (
          name === 'node_modules' ||
          name === 'dist' ||
          name === '.git' ||
          name === '.github' ||
          name === '.env' ||
          name === 'package-lock.json' ||
          name === 'server.js' ||
          name === 'nudge-ai-productivity-app.zip'
        ) {
          continue;
        }

        const fullPath = path.join(localDir, name);
        const relativeZipPath = zipDir ? `${zipDir}/${name}` : name;

        if (entry.isDirectory()) {
          addFolderToZip(fullPath, relativeZipPath);
        } else {
          try {
            zip.addFile(relativeZipPath, fs.readFileSync(fullPath));
          } catch (fileErr) {
            console.warn(`Could not add file ${relativeZipPath} to zip:`, fileErr);
          }
        }
      }
    };

    addFolderToZip(rootDir, '');

    const buffer = zip.toBuffer();
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename=nudge-ai-productivity-app.zip');
    res.send(buffer);
  } catch (error: any) {
    console.error('Failed to generate ZIP archive:', error);
    res.status(500).json({ error: 'Failed to package app source files' });
  }
});

// Classify tasks (Planning Stage)
app.post('/api/nudge/classify', async (req, res) => {
  const { name, deadline, estimatedEffort } = req.body;
  if (!name) {
    return res.status(400).json({ error: 'Task name is required' });
  }

  const client = getAIClient();
  if (!client) {
    // Return heuristic response immediately
    const fallback = runHeuristicClassifier(name, deadline || 'end of day');
    return res.json({
      name,
      deadline: deadline || '23:59',
      estimatedEffort: estimatedEffort || '30m',
      ...fallback,
      mode: 'heuristic',
    });
  }

  try {
    const prompt = `You are the classification engine for Nudge, a highly proactive AI productivity co-pilot.
Given a user's task, classify it into one of these three buckets:
- VERY_URGENT: Hard external consequence if missed today (e.g. lost money, missed interview, client meetings, bills, hard deadlines).
- URGENT: Important, time-bound, but has some flexibility (e.g. personal homework, gym, cleaning).
- DAY_END: Low time-sensitivity, can comfortably slide to the end of the day.

Task details:
- Name: "${name}"
- Deadline/Time constraint: "${deadline || 'None specified'}"
- Estimated effort: "${estimatedEffort || 'Not specified'}"

Determine:
1. Category: Must be exactly "VERY_URGENT", "URGENT", or "DAY_END".
2. Consequence: Write a short, powerful, empathetic, 1-sentence explanation of what breaks or what consequence occurs if this task is NOT completed. Be objective, realistic, and highly supportive (no shaming).
3. Action Suggestion: Write a short, highly actionable, 1-sentence tip on how to tackle this task efficiently.

Return your response in strict JSON format matching this schema:
{
  "category": "VERY_URGENT" | "URGENT" | "DAY_END",
  "consequence": "sentence describing what breaks",
  "actionSuggestion": "sentence suggesting immediate next action"
}`;

    const response = await client.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            category: { type: Type.STRING, description: 'VERY_URGENT, URGENT, or DAY_END' },
            consequence: { type: Type.STRING, description: 'What breaks if not completed today' },
            actionSuggestion: { type: Type.STRING, description: 'Actionable starting tip' },
          },
          required: ['category', 'consequence', 'actionSuggestion'],
        },
      },
    });

    const resultText = response.text || '';
    const result = JSON.parse(resultText.trim());
    
    // Safety check on categories
    let finalCategory = result.category;
    if (finalCategory !== 'VERY_URGENT' && finalCategory !== 'URGENT' && finalCategory !== 'DAY_END') {
      finalCategory = runHeuristicClassifier(name, deadline || '').category;
    }

    res.json({
      name,
      deadline: deadline || '23:59',
      estimatedEffort: estimatedEffort || '30m',
      category: finalCategory,
      consequence: result.consequence || 'Will cause backlog for tomorrow.',
      actionSuggestion: result.actionSuggestion || 'Begin immediately to maintain momentum.',
      mode: 'gemini',
    });
  } catch (error) {
    console.error('Gemini classification error, falling back:', error);
    const fallback = runHeuristicClassifier(name, deadline || 'end of day');
    res.json({
      name,
      deadline: deadline || '23:59',
      estimatedEffort: estimatedEffort || '30m',
      ...fallback,
      mode: 'heuristic-error',
    });
  }
});

// Generate dynamic, empathetic nudge messages
app.post('/api/nudge/generate-nudge', async (req, res) => {
  const { task, checkInTime, workHours } = req.body;
  if (!task) {
    return res.status(400).json({ error: 'Task is required' });
  }

  const client = getAIClient();
  if (!client) {
    const text = runHeuristicNudge(task, checkInTime);
    return res.json({ text, mode: 'heuristic' });
  }

  try {
    const prompt = `You are Nudge, an empathetic, proactive AI productivity copilot for students, professionals, and entrepreneurs.
Your job is not to passively remind, but to nudge at the right moment using the correct tone.

Generate a highly personalized check-in nudge for this task:
- Task: "${task.name}"
- Urgency: "${task.category}"
- Consequence: "${task.consequence}"
- Action Suggestion: "${task.actionSuggestion}"
- Check-In Time: "${checkInTime}"
- Working hours configuration: ${JSON.stringify(workHours || { start: '09:00', end: '18:00' })}

Tone & Behavior Rules:
- Must be short (1-3 sentences total).
- Frame the real consequence of missing the task (supportively), and offer a next small action or calendar block suggestion.
- Adjust tone to the touchpoint urgency:
  - 12:00 PM (Day-End low-urgency tasks): Light, planning-oriented, non-naggy, calming.
  - 3:00 PM (Urgent tasks): More direct status-check, proactive.
  - 6:00 PM (Very Urgent tasks): Firm, supportive, cannot-miss. Emphasize what breaks clearly, and ask to break it down.
  - EOD Alarm (Failsafe): Direct, alarm-like, but friendly final push.

Write the nudge message text. Do not include any JSON brackets or wrappers, just output the exact text of Nudge's speaking voice.`;

    const response = await client.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
    });

    const nudgeText = (response.text || '').trim();
    res.json({
      text: nudgeText || runHeuristicNudge(task, checkInTime),
      mode: 'gemini',
    });
  } catch (error) {
    console.error('Gemini nudge generation error:', error);
    const text = runHeuristicNudge(task, checkInTime);
    res.json({ text, mode: 'heuristic-error' });
  }
});

// Analyze Daily / Multi-day History & Suggest Structural Fixes
app.post('/api/nudge/pattern-analysis', async (req, res) => {
  const { history, currentTasks } = req.body;
  
  const client = getAIClient();
  if (!client) {
    // Generates a simple friendly default analysis
    const repeatedMisses: string[] = [];
    const counts: Record<string, number> = {};
    
    if (history && history.length > 0) {
      for (const day of history) {
        for (const t of day.tasksSnapshot || []) {
          if (t.outcome === 'MISSED' || t.outcome === 'IN_PROCESS') {
            counts[t.name.toLowerCase()] = (counts[t.name.toLowerCase()] || 0) + 1;
          }
        }
      }
    }
    
    Object.entries(counts).forEach(([name, count]) => {
      if (count >= 2) {
        repeatedMisses.push(name);
      }
    });

    let message = "Excellent work on completing your planning loops! Keep logging your days so I can reveal patterns and habits.";
    let suggestedFix = "";
    
    if (repeatedMisses.length > 0) {
      const missedItem = repeatedMisses[0];
      message = `I've noticed you missed "${missedItem}" multiple times recently. Instead of pushing it back, let's schedule it to an earlier hour or break it down into 15-minute intervals.`;
      suggestedFix = `Reschedule "${missedItem}" to morning slots with half the estimated duration.`;
    }

    return res.json({
      analysis: message,
      suggestedFix,
      mode: 'heuristic',
    });
  }

  try {
    const prompt = `You are Nudge, the proactive AI productivity co-pilot.
Review the user's task history and provide a high-value pattern analysis.
If the user repeatedly misses the same type of task (e.g. gym, deep work, admin tasks), you must proactively suggest a structural fix (such as choosing a different time slot, breaking it down into sub-tasks, or lowering initial commitment) rather than just scolding or repeating.

Task history across multiple days:
${JSON.stringify(history || [])}

Current day's active tasks:
${JSON.stringify(currentTasks || [])}

Provide your response in strict JSON format with these exact keys:
{
  "analysis": "A supportive, highly professional 2-3 sentence overview identifying patterns (streaks, repeated misses, or general peak productivity habits). Speak clearly and directly.",
  "suggestedFix": "A concrete structural adjustment proposal for a repeatedly missed task, or empty string if everything is on track."
}`;

    const response = await client.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            analysis: { type: Type.STRING, description: 'Empathetic pattern analysis' },
            suggestedFix: { type: Type.STRING, description: 'Proactive structural suggestion or recommendation' },
          },
          required: ['analysis', 'suggestedFix'],
        },
      },
    });

    const resultText = response.text || '';
    res.json(JSON.parse(resultText.trim()));
  } catch (error) {
    console.error('Gemini pattern analysis error:', error);
    res.json({
      analysis: "I am actively tracking your daily task patterns. Complete more days of check-ins to unlock personalized, structure-level suggestions!",
      suggestedFix: "",
      mode: 'heuristic-error',
    });
  }
});


// ---------------------------------------------------------
// Vite / Static Files Setup
// ---------------------------------------------------------

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Nudge backend server successfully running on http://localhost:${PORT}`);
  });
}

startServer();
