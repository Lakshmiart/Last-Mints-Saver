/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { WorkHours } from '../types';
import { Clock, Play, Pause, ChevronRight, Settings, Sunrise, Sun, Sunset, AlertOctagon, HelpCircle } from 'lucide-react';

interface TimelineControllerProps {
  simTime: string;
  simDay: number;
  autoAdvance: boolean;
  onToggleAutoAdvance: () => void;
  onAdvanceOneHour: () => void;
  onSetTime: (time: string) => void;
  workHours: WorkHours;
  onUpdateWorkHours: (hours: Partial<WorkHours>) => void;
  onResetSimulation: () => void;
  aiStatus: { active: boolean; info: string };
}

export default function TimelineController({
  simTime,
  simDay,
  autoAdvance,
  onToggleAutoAdvance,
  onAdvanceOneHour,
  onSetTime,
  workHours,
  onUpdateWorkHours,
  onResetSimulation,
  aiStatus,
}: TimelineControllerProps) {
  
  // Format hours for easy reading
  const formatTime12h = (time24: string) => {
    const [hStr, mStr] = time24.split(':');
    const h = parseInt(hStr, 10);
    const ampm = h >= 12 ? 'PM' : 'AM';
    const displayH = h % 12 === 0 ? 12 : h % 12;
    return `${displayH}:${mStr} ${ampm}`;
  };

  // Touchpoint timings based on work hours
  // Let's calculate standard check-ins or shifted check-ins based on workHours.start / workHours.end
  const getTimings = () => {
    const isDefault = workHours.start === '09:00' && workHours.end === '18:00';
    if (isDefault) {
      return [
        { label: 'Check-In #1 (Day-End)', time: '12:00', icon: Sun, desc: 'Low-urgency check-in' },
        { label: 'Check-In #2 (Urgent)', time: '15:00', icon: Sunset, desc: 'Urgent status check' },
        { label: 'Check-In #3 (Very Urgent)', time: '17:45', icon: AlertOctagon, desc: 'Firm consequence-framed check-in' },
        { label: 'Check-In #4 (EOD Alarm)', time: '22:30', icon: Clock, desc: 'Final failsafe deadline alarm' },
        { label: 'Night Review', time: '21:30', icon: Sunset, desc: 'Outcome evaluation and carry-over seeding' },
        { label: 'Planning Mode', time: '20:00', icon: Sunrise, desc: 'Gather tasks for next day' },
      ];
    } else {
      // Custom shifted hours
      // Simple parse to hours
      const startH = parseInt(workHours.start.split(':')[0], 10);
      const endH = parseInt(workHours.end.split(':')[0], 10);
      const span = (endH - startH + 24) % 24;

      const formatPad = (h: number) => `${String((h + 24) % 24).padStart(2, '0')}:00`;

      const t1 = formatPad(startH + Math.round(span * 0.33)); // 1/3 in
      const t2 = formatPad(startH + Math.round(span * 0.66)); // 2/3 in
      const t3 = formatPad(startH + Math.round(span * 0.90)); // near EOD
      const t4 = workHours.end; // exactly end of work day
      const tReview = formatPad(endH + 1); // 1hr past end
      const tPlanning = formatPad(endH + 2); // 2hr past end

      return [
        { label: 'Check-In #1 (Day-End)', time: t1, icon: Sun, desc: 'Shift-adjusted low-urgency check' },
        { label: 'Check-In #2 (Urgent)', time: t2, icon: Sunset, desc: 'Shift-adjusted urgent check' },
        { label: 'Check-In #3 (Very Urgent)', time: t3, icon: AlertOctagon, desc: 'Shift-adjusted critical check' },
        { label: 'Check-In #4 (EOD Alarm)', time: t4, icon: Clock, desc: 'Final failsafe deadline alarm' },
        { label: 'Night Review', time: tReview, icon: Sunset, desc: 'Shift-adjusted outcome evaluation' },
        { label: 'Planning Mode', time: tPlanning, icon: Sunrise, desc: 'Shift-adjusted next day prep' },
      ];
    }
  };

  const timings = getTimings();

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-6">
      
      {/* Simulation Clock Display */}
      <div className="flex items-center justify-between">
        <div>
          <span className="text-xs font-semibold tracking-wider text-slate-400 uppercase font-mono">
            Simulation Control Panel
          </span>
          <h2 className="text-2xl font-black text-white flex items-center gap-2 mt-1">
            <span className="text-emerald-400">Day {simDay}</span>
            <span className="text-slate-500 font-normal">|</span>
            <span className="font-mono text-emerald-300 font-bold tracking-tight bg-slate-950 px-3 py-1 rounded-xl border border-slate-800/80">
              {formatTime12h(simTime)}
            </span>
          </h2>
        </div>

        {/* AI status badge */}
        <div className="text-right">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-950 border border-slate-800">
            <span className={`w-2 h-2 rounded-full ${aiStatus.active ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
            {aiStatus.active ? 'Gemini 3.5 Active' : 'Heuristic Mode'}
          </span>
          <p className="text-[10px] text-slate-500 font-mono mt-1 max-w-[120px] truncate">
            {aiStatus.info}
          </p>
        </div>
      </div>

      {/* Play/Pause / Manual increment buttons */}
      <div className="flex items-center gap-3 p-3 bg-slate-950 rounded-xl border border-slate-800/60">
        <button
          onClick={onToggleAutoAdvance}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-sm font-semibold transition-all ${
            autoAdvance
              ? 'bg-amber-600 text-white shadow-lg shadow-amber-900/30'
              : 'bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700'
          }`}
        >
          {autoAdvance ? (
            <>
              <Pause className="h-4 w-4" />
              Auto-Advancing
            </>
          ) : (
            <>
              <Play className="h-4 w-4" />
              Simulate Day
            </>
          )}
        </button>

        <button
          onClick={onAdvanceOneHour}
          className="px-3 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 transition flex items-center justify-center gap-1 text-sm font-semibold"
          title="Advance 1 Hour"
        >
          <span>+1 hr</span>
          <ChevronRight className="h-4 w-4" />
        </button>
      </div>

      {/* Preset Touchpoints for Testing */}
      <div className="space-y-2.5">
        <h3 className="text-xs font-bold text-slate-400 uppercase font-mono tracking-wider">
          Jump to Touchpoint Presets
        </h3>
        <div className="grid grid-cols-2 gap-2">
          {timings.map((t, idx) => {
            const IconComponent = t.icon;
            const isNearCurrent = simTime === t.time;
            return (
              <button
                key={idx}
                onClick={() => onSetTime(t.time)}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  isNearCurrent
                    ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-200 shadow-sm shadow-emerald-950'
                    : 'bg-slate-950 hover:bg-slate-900 border-slate-800 text-slate-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  <IconComponent className={`h-4 w-4 flex-shrink-0 ${isNearCurrent ? 'text-emerald-400' : 'text-slate-500'}`} />
                  <span className="text-[11px] font-black tracking-tight font-mono text-emerald-300/90 bg-slate-900/60 px-1 py-0.5 rounded">
                    {formatTime12h(t.time)}
                  </span>
                </div>
                <div className="text-[11px] font-semibold mt-1 truncate">
                  {t.label}
                </div>
                <div className="text-[9px] text-slate-500 font-mono leading-tight mt-0.5 truncate">
                  {t.desc}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Adjust Working Hours */}
      <div className="p-4 bg-slate-950 rounded-xl border border-slate-800/80 space-y-3">
        <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">
          <Settings className="h-3.5 w-3.5 text-indigo-400" />
          Shift Working Hours
        </div>
        <p className="text-[10px] text-slate-400 font-sans leading-relaxed">
          Nudge automatically recalibrates its 4 daily check-ins to match your active shift hours.
        </p>
        <div className="grid grid-cols-2 gap-3 pt-1">
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase font-mono mb-1">
              Shift Starts
            </label>
            <input
              type="time"
              value={workHours.start}
              onChange={(e) => onUpdateWorkHours({ start: e.target.value })}
              className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase font-mono mb-1">
              Shift Ends (EOD)
            </label>
            <input
              type="time"
              value={workHours.end}
              onChange={(e) => onUpdateWorkHours({ end: e.target.value })}
              className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>
      </div>

      {/* Reset Simulation */}
      <button
        onClick={onResetSimulation}
        className="w-full text-center py-2 text-xs text-slate-500 hover:text-slate-300 font-semibold underline underline-offset-4 decoration-dotted cursor-pointer hover:bg-slate-950/20 rounded transition"
      >
        Reset Simulator History & State
      </button>

    </div>
  );
}
