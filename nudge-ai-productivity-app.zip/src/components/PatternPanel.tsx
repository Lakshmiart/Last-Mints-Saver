/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { DailySummary } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { TrendingUp, Award, AlertTriangle, CheckCircle, HelpCircle, Activity, Lightbulb, Check, FileSpreadsheet } from 'lucide-react';

interface PatternPanelProps {
  history: DailySummary[];
  aiAnalysis: string;
  suggestedFix: string;
  onApplyFix: (fixText: string) => void;
  isFixApplied: boolean;
  streakCount: number;
}

export default function PatternPanel({
  history,
  aiAnalysis,
  suggestedFix,
  onApplyFix,
  isFixApplied,
  streakCount,
}: PatternPanelProps) {
  
  // Calculate aggregated stats
  const totalOnTime = history.reduce((sum, d) => sum + d.onTimeCount, 0);
  const totalInProcess = history.reduce((sum, d) => sum + d.inProcessCount, 0);
  const totalMissed = history.reduce((sum, d) => sum + d.missedCount, 0);
  const totalTasks = totalOnTime + totalInProcess + totalMissed;
  
  const completionRate = totalTasks > 0 ? Math.round((totalOnTime / totalTasks) * 100) : 0;

  // Handles compiling and exporting the Daily Summary snapshots as a CSV file
  const handleExportCSV = () => {
    if (history.length === 0) return;

    // Headers
    const headers = [
      'Day',
      'Date',
      'On Time Count',
      'In Process Count',
      'Missed Count',
      'Total Tasks',
      'Completion Rate (%)',
      'AI Analysis Summary',
      'Task Names & Outcomes'
    ];

    // Rows
    const rows = history.map(dayLog => {
      const total = dayLog.onTimeCount + dayLog.inProcessCount + dayLog.missedCount;
      const rate = total > 0 ? Math.round((dayLog.onTimeCount / total) * 100) : 0;
      
      // Serialize tasks snapshots nicely
      const tasksStr = (dayLog.tasksSnapshot || [])
        .map(t => `${t.name} (${t.category} - ${t.outcome})`)
        .join('; ');

      // Escape fields for CSV safely
      const escape = (val: any) => {
        const str = String(val ?? '');
        return `"${str.replace(/"/g, '""')}"`;
      };

      return [
        dayLog.day,
        dayLog.dateString,
        dayLog.onTimeCount,
        dayLog.inProcessCount,
        dayLog.missedCount,
        total,
        rate,
        dayLog.aiAnalysis,
        tasksStr
      ].map(escape).join(',');
    });

    const csvContent = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `nudge_daily_summaries_export.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      
      {/* Streaks & Performance Grid */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <Award className="h-5 w-5 text-amber-400 mx-auto mb-1" />
          <span className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono">
            Active Streak
          </span>
          <span className="text-xl font-extrabold text-white">
            {streakCount} {streakCount === 1 ? 'Day' : 'Days'}
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <TrendingUp className="h-5 w-5 text-emerald-400 mx-auto mb-1" />
          <span className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono">
            On-Time Rate
          </span>
          <span className="text-xl font-extrabold text-white">
            {completionRate}%
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 text-center">
          <Activity className="h-5 w-5 text-indigo-400 mx-auto mb-1" />
          <span className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono">
            Cycles Logged
          </span>
          <span className="text-xl font-extrabold text-white">
            {history.length}
          </span>
        </div>
      </div>

      {/* AI Proactive Pattern Diagnostics */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-indigo-950/50 border border-indigo-500/30">
            <Lightbulb className="h-4 w-4 text-indigo-400 animate-pulse" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">
              AI Pattern Diagnostics
            </h3>
            <span className="text-[10px] text-slate-500">Proactive Habit Auditing</span>
          </div>
        </div>

        {/* Dynamic AI Analysis Text */}
        <div className="bg-slate-950 rounded-xl p-4 border border-slate-800/80">
          <p className="text-xs text-slate-300 leading-relaxed font-medium">
            "{aiAnalysis}"
          </p>
        </div>

        {/* Structural Recommendation Trigger */}
        <AnimatePresence>
          {suggestedFix && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              <div className="bg-indigo-950/20 border border-indigo-500/30 rounded-xl p-4 space-y-3">
                <div className="flex items-start gap-2.5">
                  <AlertTriangle className="h-4.5 w-4.5 text-indigo-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <h4 className="text-xs font-bold text-indigo-300">
                      Proposed Structural Fix
                    </h4>
                    <p className="text-[11px] text-indigo-200/90 leading-normal mt-1">
                      {suggestedFix}
                    </p>
                  </div>
                </div>

                <div className="flex justify-end pt-1">
                  {isFixApplied ? (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-indigo-900/40 text-indigo-300 text-xs font-semibold border border-indigo-500/40">
                      <Check className="h-3.5 w-3.5 stroke-[3]" />
                      Fix Applied to Future Tasks
                    </span>
                  ) : (
                    <button
                      onClick={() => onApplyFix(suggestedFix)}
                      className="px-3 py-1.5 rounded bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition shadow-md shadow-indigo-900/20 cursor-pointer"
                    >
                      Apply Structural Adjustment
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Historical Logs List */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">
              Past Day Reviews
            </h3>
            <p className="text-[10px] text-slate-500 font-medium">Long-term productivity snapshots</p>
          </div>
          {history.length > 0 && (
            <button
              onClick={handleExportCSV}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600/20 hover:bg-indigo-600 border border-indigo-500/30 hover:border-indigo-400 text-indigo-300 hover:text-white text-[11px] font-bold transition-all cursor-pointer shadow-sm"
              title="Export long-term productivity patterns as CSV"
            >
              <FileSpreadsheet className="h-3.5 w-3.5" />
              Export CSV
            </button>
          )}
        </div>
        
        {history.length === 0 ? (
          <div className="text-center py-6 border border-dashed border-slate-800 rounded-xl text-xs text-slate-500 font-mono">
            No completed days on record. Complete your first Night Review to start logging logs.
          </div>
        ) : (
          <div className="space-y-3 max-h-[220px] overflow-y-auto pr-1">
            {history.slice().reverse().map((dayLog) => (
              <div
                key={dayLog.day}
                className="p-3 bg-slate-950 border border-slate-850 rounded-xl space-y-2 text-xs"
              >
                <div className="flex items-center justify-between font-mono">
                  <span className="font-bold text-slate-300">Day {dayLog.day} Summary</span>
                  <span className="text-[10px] text-slate-500">{dayLog.dateString}</span>
                </div>
                
                <div className="grid grid-cols-3 gap-2 py-1 text-center font-mono text-[11px]">
                  <div className="bg-emerald-950/20 border border-emerald-900/30 text-emerald-300 py-1 rounded">
                    On Time: <strong>{dayLog.onTimeCount}</strong>
                  </div>
                  <div className="bg-amber-950/20 border border-amber-900/30 text-amber-300 py-1 rounded">
                    In Process: <strong>{dayLog.inProcessCount}</strong>
                  </div>
                  <div className="bg-rose-950/20 border border-rose-900/30 text-rose-300 py-1 rounded">
                    Missed: <strong>{dayLog.missedCount}</strong>
                  </div>
                </div>

                <p className="text-[11px] text-slate-400 leading-normal italic">
                  "{dayLog.aiAnalysis}"
                </p>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
}
