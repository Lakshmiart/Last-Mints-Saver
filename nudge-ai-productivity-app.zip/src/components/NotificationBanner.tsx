/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bell, AlertTriangle, CheckCircle, Info, X } from 'lucide-react';

interface NotificationBannerProps {
  notification: {
    id: string;
    text: string;
    type: 'info' | 'warning' | 'error' | 'success';
    title: string;
  } | null;
  onClose: () => void;
}

export default function NotificationBanner({ notification, onClose }: NotificationBannerProps) {
  // Play a soft synthetic beep/bell sound when a warning or error occurs
  useEffect(() => {
    if (notification && (notification.type === 'error' || notification.type === 'warning')) {
      try {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        
        // Custom synthesizer notification chime: two pleasant notes (C5 -> G5)
        const playTone = (freq: number, start: number, duration: number) => {
          const osc = audioCtx.createOscillator();
          const gainNode = audioCtx.createGain();
          
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, start);
          
          gainNode.gain.setValueAtTime(0.15, start);
          gainNode.gain.exponentialRampToValueAtTime(0.001, start + duration);
          
          osc.connect(gainNode);
          gainNode.connect(audioCtx.destination);
          
          osc.start(start);
          osc.stop(start + duration);
        };

        const now = audioCtx.currentTime;
        if (notification.type === 'error') {
          // Hard failsafe alarm sound (more urgent chime)
          playTone(523.25, now, 0.15); // C5
          playTone(523.25, now + 0.18, 0.15); // C5
          playTone(659.25, now + 0.36, 0.4);  // E5
        } else {
          // Soft check-in sound
          playTone(587.33, now, 0.15); // D5
          playTone(880.00, now + 0.15, 0.35); // A5
        }
      } catch (e) {
        console.warn('Audio synthesis not supported or blocked by user interaction:', e);
      }
    }
  }, [notification]);

  return (
    <AnimatePresence>
      {notification && (
        <motion.div
          id="notification-banner"
          initial={{ opacity: 0, y: -50, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -20, scale: 0.95 }}
          className="fixed top-4 left-1/2 -translate-x-1/2 z-50 w-full max-w-md px-4"
        >
          <div
            className={`relative flex items-start gap-3 p-4 rounded-xl border shadow-xl backdrop-blur-md ${
              notification.type === 'error'
                ? 'bg-rose-950/90 border-rose-500/50 text-rose-200'
                : notification.type === 'warning'
                ? 'bg-amber-950/90 border-amber-500/50 text-amber-200'
                : notification.type === 'success'
                ? 'bg-emerald-950/90 border-emerald-500/50 text-emerald-200'
                : 'bg-slate-900/90 border-slate-700 text-slate-100'
            }`}
          >
            <div className="mt-0.5 flex-shrink-0">
              {notification.type === 'error' && <AlertTriangle className="h-5 w-5 text-rose-400 animate-pulse" />}
              {notification.type === 'warning' && <Bell className="h-5 w-5 text-amber-400 animate-bounce" />}
              {notification.type === 'success' && <CheckCircle className="h-5 w-5 text-emerald-400" />}
              {notification.type === 'info' && <Info className="h-5 w-5 text-blue-400" />}
            </div>
            
            <div className="flex-1 min-w-0 pr-6">
              <p className="text-sm font-semibold tracking-wide uppercase">
                {notification.title}
              </p>
              <p className="mt-1 text-xs leading-relaxed opacity-90">
                {notification.text}
              </p>
            </div>

            <button
              onClick={onClose}
              className="absolute top-3 right-3 p-1 rounded-lg text-slate-400 hover:bg-white/10 hover:text-white transition-colors"
              aria-label="Close"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
