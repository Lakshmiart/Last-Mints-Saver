/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Task } from '../types';
import { motion } from 'motion/react';
import { 
  Check, 
  Clock, 
  AlertCircle, 
  ArrowUpRight, 
  ShieldAlert, 
  Sparkles, 
  Play, 
  Pause, 
  Timer,
  Volume2
} from 'lucide-react';
import { parseEffortToMinutes, getMinutesDiff, timeToMinutes } from '../utils/time';

interface TaskItemProps {
  key?: string;
  task: Task;
  simTime: string;
  onToggleComplete: (id: string) => void;
  onSnooze: (id: string) => void;
  onMoveTomorrow: (id: string) => void;
  onToggleFocus: (id: string) => void;
}

export default function TaskItem({ 
  task, 
  simTime,
  onToggleComplete, 
  onSnooze, 
  onMoveTomorrow,
  onToggleFocus
}: TaskItemProps) {
  const isCompleted = task.outcome === 'ON_TIME' || task.outcome === 'IN_PROCESS';
  
  const urgencyColors = {
    VERY_URGENT: {
      bg: 'bg-rose-500/10 border-rose-500/30 text-rose-300',
      badge: 'bg-rose-600/30 text-rose-200 border-rose-500/30',
      iconColor: 'text-rose-400',
      tag: 'Very Urgent'
    },
    URGENT: {
      bg: 'bg-amber-500/10 border-amber-500/30 text-amber-300',
      badge: 'bg-amber-600/30 text-amber-200 border-amber-500/30',
      iconColor: 'text-amber-400',
      tag: 'Urgent'
    },
    DAY_END: {
      bg: 'bg-slate-500/10 border-slate-700 text-slate-300',
      badge: 'bg-slate-700/50 text-slate-300 border-slate-600',
      iconColor: 'text-slate-400',
      tag: 'Day-End Task'
    }
  };

  const style = urgencyColors[task.category] || urgencyColors.DAY_END;

  // Remaining time countdown calculation
  const getRemainingTimeText = () => {
    if (isCompleted) return null;
    
    const currentMins = timeToMinutes(simTime);
    const deadlineMins = timeToMinutes(task.deadline);
    
    if (currentMins > deadlineMins) {
      const overdueMins = currentMins - deadlineMins;
      const h = Math.floor(overdueMins / 60);
      const m = overdueMins % 60;
      return {
        text: `Overdue by ${h > 0 ? `${h}h ` : ''}${m}m`,
        color: 'text-rose-400 bg-rose-950/60 border-rose-800/50',
        isOverdue: true
      };
    } else {
      const remainingMins = deadlineMins - currentMins;
      const h = Math.floor(remainingMins / 60);
      const m = remainingMins % 60;
      
      let color = 'text-emerald-400 bg-emerald-950/40 border-emerald-800/40';
      if (remainingMins <= 30) {
        color = 'text-rose-400 bg-rose-950/60 border-rose-500/30 animate-pulse';
      } else if (remainingMins <= 120) {
        color = 'text-amber-300 bg-amber-950/30 border-amber-800/30';
      }
      
      return {
        text: `${h > 0 ? `${h}h ` : ''}${m}m left`,
        color,
        isOverdue: false
      };
    }
  };

  const remaining = getRemainingTimeText();

  // Effort progress bar calculations
  const totalEffortMinutes = parseEffortToMinutes(task.estimatedEffort);
  const timeSpent = task.timeSpent || 0;
  const progressPercent = Math.min(100, Math.round((timeSpent / totalEffortMinutes) * 100));

  // Determine if we show warning for 30m left
  const currentMins = timeToMinutes(simTime);
  const deadlineMins = timeToMinutes(task.deadline);
  const remainingMins = deadlineMins - currentMins;
  const show30mWarning = !isCompleted && remainingMins > 0 && remainingMins <= 30;

  return (
    <motion.div
      id={`task-card-${task.id}`}
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      whileHover={{ y: -1 }}
      className={`p-4 rounded-xl border transition-all duration-300 ${style.bg} ${
        isCompleted ? 'opacity-50 bg-slate-900/40 border-slate-800' : ''
      } ${
        task.isFocused && !isCompleted 
          ? 'ring-2 ring-emerald-500 border-transparent shadow-lg shadow-emerald-950/30 bg-emerald-950/10' 
          : ''
      }`}
    >
      <div className="flex items-start gap-3">
        {/* Checkbox button */}
        <button
          onClick={() => onToggleComplete(task.id)}
          className={`mt-0.5 flex-shrink-0 w-6 h-6 rounded-lg border flex items-center justify-center transition-all cursor-pointer ${
            isCompleted
              ? 'bg-emerald-600 border-emerald-500 text-white shadow-inner'
              : 'border-slate-500 hover:border-slate-300 bg-slate-950'
          }`}
          aria-label={isCompleted ? "Mark incomplete" : "Mark completed"}
        >
          {isCompleted && <Check className="h-4 w-4 stroke-[3]" />}
        </button>

        {/* Task details */}
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h4
              className={`text-sm font-bold leading-snug truncate ${
                isCompleted ? 'line-through text-slate-500 font-normal' : 'text-slate-100 font-bold'
              }`}
            >
              {task.name}
            </h4>
            
            {/* Urgency Badge */}
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase font-mono tracking-wider ${style.badge}`}>
              {style.tag}
            </span>

            {/* Carry Over Indicator */}
            {task.carriedOver && (
              <span className="text-[10px] font-bold px-2 py-0.5 rounded border border-indigo-500/30 bg-indigo-950/40 text-indigo-300 flex items-center gap-0.5 animate-pulse font-mono uppercase tracking-wider">
                <ArrowUpRight className="h-3 w-3" />
                Carry-Over (+1 Urgency)
              </span>
            )}

            {/* Focus status badge */}
            {task.isFocused && !isCompleted && (
              <span className="text-[10px] font-extrabold px-2 py-0.5 rounded border border-emerald-500 bg-emerald-950 text-emerald-400 flex items-center gap-1 font-mono tracking-widest animate-pulse">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                FOCUS ACTIVE
              </span>
            )}
          </div>

          <div className="mt-2.5 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-slate-400 font-mono">
            <span className="flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5 text-slate-500" />
              Deadline: <strong className="text-slate-200">{task.deadline}</strong>
            </span>
            
            <span className="flex items-center gap-1.5">
              <Timer className="h-3.5 w-3.5 text-slate-500" />
              Effort: <strong className="text-slate-200">{task.estimatedEffort}</strong>
            </span>

            {/* Time Remaining countdown badge */}
            {remaining && (
              <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-[10px] font-bold ${remaining.color}`}>
                {remaining.text}
              </span>
            )}

            {task.completedAtSimTime && (
              <span className="text-emerald-300 font-mono font-bold bg-emerald-950/50 px-2.5 py-0.5 rounded-lg border border-emerald-500/30 shadow-[0_0_8px_rgba(16,185,129,0.15)] flex items-center gap-1 animate-pulse">
                Completed at {task.completedAtSimTime}
              </span>
            )}
          </div>

          {/* Time spent visual bar and statistics */}
          {!isCompleted && (
            <div className="mt-3 bg-slate-950 p-2.5 rounded-xl border border-slate-800/60">
              <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 mb-1">
                <span>Time Spent Focus: <strong className="text-slate-200">{timeSpent}m</strong> / {totalEffortMinutes}m</span>
                <span className={progressPercent >= 100 ? 'text-emerald-400' : 'text-indigo-400'}>{progressPercent}% Done</span>
              </div>
              <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-800">
                <div 
                  className={`h-full rounded-full transition-all duration-500 ${
                    task.isFocused ? 'bg-gradient-to-r from-emerald-500 to-teal-400 animate-pulse' : 'bg-indigo-600'
                  }`} 
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>
          )}

          {/* Assistant Voice notification visual notification card */}
          {show30mWarning && (
            <div className="mt-2.5 p-2 bg-rose-950/20 border border-rose-500/20 rounded-xl flex items-center gap-2 text-[11px] text-rose-300">
              <Volume2 className="h-3.5 w-3.5 text-rose-400 animate-bounce flex-shrink-0" />
              <p className="font-sans leading-tight">
                <strong className="text-rose-400">Assistant Warning:</strong> 30 more mins left to finish! Complete the task or snooze to avoid consequences.
              </p>
            </div>
          )}

          {/* AI insights (consequence and action tip) expanded unless completed */}
          {!isCompleted && (
            <div className="mt-3 pt-2.5 border-t border-slate-800/60 space-y-2">
              {task.consequence && (
                <div className="flex items-start gap-1.5 text-xs text-rose-300/90 leading-relaxed bg-rose-950/20 p-1.5 rounded border border-rose-950/30">
                  <ShieldAlert className="h-3.5 w-3.5 mt-0.5 flex-shrink-0 text-rose-400" />
                  <div>
                    <span className="font-semibold text-rose-400 font-sans">If missed:</span> {task.consequence}
                  </div>
                </div>
              )}
              {task.actionSuggestion && (
                <div className="flex items-start gap-1.5 text-xs text-emerald-300/95 leading-relaxed bg-emerald-950/20 p-1.5 rounded border border-emerald-950/30">
                  <Sparkles className="h-3.5 w-3.5 mt-0.5 flex-shrink-0 text-emerald-400" />
                  <div>
                    <span className="font-semibold text-emerald-400 font-sans">Nudge Advice:</span> {task.actionSuggestion}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Action buttons (Focus Timer, Snooze, Defer) */}
      {!isCompleted && (
        <div className="mt-3.5 pt-2.5 border-t border-slate-800/40 flex flex-wrap items-center justify-between gap-2 text-xs">
          {/* Focus mode control */}
          <button
            onClick={() => onToggleFocus(task.id)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              task.isFocused
                ? 'bg-amber-600 hover:bg-amber-500 text-white shadow shadow-amber-900/40 border border-amber-500/30'
                : 'bg-emerald-600/20 border border-emerald-500/30 text-emerald-300 hover:bg-emerald-600/30 hover:text-white'
            }`}
          >
            {task.isFocused ? (
              <>
                <Pause className="h-3.5 w-3.5 animate-spin" />
                Pause Focus
              </>
            ) : (
              <>
                <Play className="h-3.5 w-3.5" />
                Start Focus
              </>
            )}
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onSnooze(task.id)}
              className="px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-slate-300 hover:text-white hover:bg-slate-800 transition cursor-pointer"
            >
              Snooze 1hr
            </button>
            <button
              onClick={() => onMoveTomorrow(task.id)}
              className="px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-slate-300 hover:text-white hover:bg-slate-800 transition cursor-pointer"
            >
              Defer Tomorrow
            </button>
          </div>
        </div>
      )}
    </motion.div>
  );
}
