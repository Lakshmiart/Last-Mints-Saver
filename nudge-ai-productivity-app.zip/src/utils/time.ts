/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Parses estimated effort string (e.g. "30m", "1h 30m", "2h", "1.5h") into minutes
 */
export function parseEffortToMinutes(effortStr: string): number {
  if (!effortStr) return 30; // default 30 mins
  
  const normalized = effortStr.toLowerCase().trim();
  let totalMinutes = 0;
  
  // Find hours (handles integers and floats like "1.5h")
  const hoursMatch = normalized.match(/(\d+(?:\.\d+)?)\s*h/);
  if (hoursMatch) {
    totalMinutes += parseFloat(hoursMatch[1]) * 60;
  }
  
  // Find minutes
  const minsMatch = normalized.match(/(\d+)\s*m/);
  if (minsMatch) {
    totalMinutes += parseInt(minsMatch[1], 10);
  }
  
  // Fallback if no specific units match but a plain number is given
  if (totalMinutes === 0) {
    const rawNum = parseInt(normalized, 10);
    if (!isNaN(rawNum)) {
      totalMinutes = rawNum;
    } else {
      totalMinutes = 30; // fallback default
    }
  }
  
  return totalMinutes;
}

/**
 * Calculates simulated minutes between midnight and HH:MM
 */
export function timeToMinutes(timeStr: string): number {
  const [h, m] = timeStr.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

/**
 * Calculates minutes difference between two 24h times
 */
export function getMinutesDiff(fromTime: string, toTime: string): number {
  const min1 = timeToMinutes(fromTime);
  let min2 = timeToMinutes(toTime);
  
  if (min2 < min1) {
    // Wrap around 24 hours
    min2 += 24 * 60;
  }
  return min2 - min1;
}

/**
 * Gets the current real-world local clock time in 24h HH:MM format
 */
export function getRealTime24h(): string {
  const now = new Date();
  const hh = String(now.getHours()).padStart(2, '0');
  const mm = String(now.getMinutes()).padStart(2, '0');
  return `${hh}:${mm}`;
}

/**
 * Speaks message via Web Speech API with a female voice if available
 */
export function speakText(text: string, voiceEnabled: boolean = true) {
  if (!voiceEnabled) return;
  if (!('speechSynthesis' in window)) {
    console.warn("Speech synthesis not supported in this browser.");
    return;
  }
  
  try {
    // Cancel current speaking to prevent piling up
    window.speechSynthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Try to grab a female voice
    const voices = window.speechSynthesis.getVoices();
    const femaleVoice = voices.find(voice => {
      const name = voice.name.toLowerCase();
      return (
        name.includes('female') ||
        name.includes('samantha') ||
        name.includes('zira') ||
        name.includes('google us english') ||
        name.includes('hazel') ||
        name.includes('karen') ||
        name.includes('salli') ||
        name.includes('veena') ||
        name.includes('moira') ||
        name.includes('tessa')
      );
    });
    
    if (femaleVoice) {
      utterance.voice = femaleVoice;
    }
    
    utterance.pitch = 1.15; // Friendly assistant pitch
    utterance.rate = 1.0;
    
    window.speechSynthesis.speak(utterance);
  } catch (err) {
    console.error("Speech Synthesis Error:", err);
  }
}

/**
 * Web Audio API chimes for Google Assistant / Alexa vibe
 * Synthesizes high-quality sound waves in the browser
 */
export function playChime(type: 'start' | 'success' | 'error') {
  const AudioContextClass = (window as any).AudioContext || (window as any).webkitAudioContext;
  if (!AudioContextClass) {
    console.warn("Web Audio API not supported in this browser.");
    return;
  }
  
  try {
    const ctx = new AudioContextClass();
    
    if (type === 'start') {
      // Pleasant double bubble chime (Google Assistant / Alexa style)
      // First high soft chime, followed by second higher sweet chime
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gainNode = ctx.createGain();
      
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc1.frequency.exponentialRampToValueAtTime(783.99, ctx.currentTime + 0.12); // G5
      
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(783.99, ctx.currentTime + 0.1); 
      osc2.frequency.exponentialRampToValueAtTime(1046.50, ctx.currentTime + 0.22); // C6
      
      gainNode.gain.setValueAtTime(0.04, ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.35);
      
      osc1.connect(gainNode);
      gainNode.connect(ctx.destination);
      osc1.start();
      osc1.stop(ctx.currentTime + 0.2);
      
      setTimeout(() => {
        try {
          osc2.connect(gainNode);
          osc2.start();
          osc2.stop(ctx.currentTime + 0.35);
        } catch (e) {}
      }, 100);
      
    } else if (type === 'success') {
      // Success chime: cheerful and rapid rising sequence
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const osc3 = ctx.createOscillator();
      const gainNode = ctx.createGain();
      
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(659.25, ctx.currentTime); // E5
      
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(783.99, ctx.currentTime + 0.08); // G5
      
      osc3.type = 'sine';
      osc3.frequency.setValueAtTime(1046.50, ctx.currentTime + 0.16); // C6
      
      gainNode.gain.setValueAtTime(0.05, ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.45);
      
      osc1.connect(gainNode);
      gainNode.connect(ctx.destination);
      osc1.start();
      osc1.stop(ctx.currentTime + 0.2);
      
      setTimeout(() => {
        try {
          osc2.connect(gainNode);
          osc2.start();
          osc2.stop(ctx.currentTime + 0.3);
        } catch (e) {}
      }, 80);
      
      setTimeout(() => {
        try {
          osc3.connect(gainNode);
          osc3.start();
          osc3.stop(ctx.currentTime + 0.45);
        } catch (e) {}
      }, 160);
      
    } else if (type === 'error') {
      // Low dual-tone descending beep
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gainNode = ctx.createGain();
      
      osc1.type = 'triangle';
      osc1.frequency.setValueAtTime(220, ctx.currentTime); // A3
      osc1.frequency.linearRampToValueAtTime(180, ctx.currentTime + 0.15);
      
      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(180, ctx.currentTime + 0.12);
      osc2.frequency.linearRampToValueAtTime(140, ctx.currentTime + 0.3);
      
      gainNode.gain.setValueAtTime(0.06, ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.35);
      
      osc1.connect(gainNode);
      gainNode.connect(ctx.destination);
      osc1.start();
      osc1.stop(ctx.currentTime + 0.2);
      
      setTimeout(() => {
        try {
          osc2.connect(gainNode);
          osc2.start();
          osc2.stop(ctx.currentTime + 0.35);
        } catch (e) {}
      }, 120);
    }
  } catch (err) {
    console.warn("Audio Context sound failed to play:", err);
  }
}
