/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type TaskUrgency = 'VERY_URGENT' | 'URGENT' | 'DAY_END';
export type TaskOutcome = 'PENDING' | 'ON_TIME' | 'IN_PROCESS' | 'MISSED';
export type MessageType = 'SYSTEM' | 'PLANNING' | 'NUDGE' | 'ALARM' | 'REVIEW' | 'CHAT';

export interface Task {
  id: string;
  name: string;
  deadline: string; // e.g. "18:00"
  estimatedEffort: string; // e.g. "30m", "1h 30m"
  category: TaskUrgency;
  outcome: TaskOutcome;
  carriedOver: boolean;
  bumpedCount: number;
  consequence: string;
  actionSuggestion: string;
  completedAtSimTime?: string; // Time of completion
  isFocused?: boolean; // Active focus tracking state
  timeSpent?: number; // Accumulated focus minutes
  notified30m?: boolean; // Whether the 30-minutes-left TTS played
}

export interface NudgeMessage {
  id: string;
  sender: 'AI' | 'USER';
  text: string;
  timestamp: string; // Simulated time like "Day 1 - 12:00 PM"
  type: MessageType;
  quickReplies?: string[];
  metadata?: {
    taskId?: string;
    suggestedFix?: string;
    subtasks?: string[];
    streakCount?: number;
  };
}

export interface DailySummary {
  day: number;
  dateString: string;
  onTimeCount: number;
  inProcessCount: number;
  missedCount: number;
  tasksSnapshot: Task[];
  aiAnalysis: string;
}

export interface WorkHours {
  start: string; // e.g. "09:00"
  end: string; // e.g. "18:00"
}
