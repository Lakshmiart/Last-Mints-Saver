/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Task, TaskUrgency, TaskOutcome, NudgeMessage, DailySummary, WorkHours } from './types';
import { parseEffortToMinutes, getMinutesDiff, timeToMinutes, speakText, playChime, getRealTime24h } from './utils/time';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  Send,
  Plus,
  Calendar,
  Clock,
  ArrowRight,
  RefreshCw,
  Bell,
  Trash2,
  Moon,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  CircleAlert,
  Sliders,
  LogOut,
  HelpCircle,
  FileSpreadsheet,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Settings,
  Download
} from 'lucide-react';

import TaskItem from './components/TaskItem';
import TimelineController from './components/TimelineController';
import PatternPanel from './components/PatternPanel';
import NotificationBanner from './components/NotificationBanner';

// Mock/Initial Task list for Day 1
const INITIAL_TASKS: Task[] = [
  {
    id: '1',
    name: 'Submit quarter budget proposal',
    deadline: '17:00',
    estimatedEffort: '1h',
    category: 'VERY_URGENT',
    outcome: 'PENDING',
    carriedOver: false,
    bumpedCount: 0,
    consequence: 'Late submittal breaks the financial schedule and delays team project signoffs.',
    actionSuggestion: 'Identify the top 3 core spreadsheet figures and draft the outline first.'
  },
  {
    id: '2',
    name: 'Go to the gym (Strength training)',
    deadline: '19:00',
    estimatedEffort: '45m',
    category: 'URGENT',
    outcome: 'PENDING',
    carriedOver: false,
    bumpedCount: 0,
    consequence: 'Skipping breaks your active fitness streak and physical momentum.',
    actionSuggestion: 'Set out your gym apparel now to reduce visual friction.'
  },
  {
    id: '3',
    name: 'Read 10 pages of research paper',
    deadline: '22:00',
    estimatedEffort: '20m',
    category: 'DAY_END',
    outcome: 'PENDING',
    carriedOver: false,
    bumpedCount: 0,
    consequence: 'Delays progress on your professional thesis backlog.',
    actionSuggestion: 'Commit to reading just 3 pages to initiate a flow state.'
  }
];

export default function App() {
  // --- Persistent Storage State ---
  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem('nudge_active_tasks');
    return saved ? JSON.parse(saved) : INITIAL_TASKS;
  });

  const [history, setHistory] = useState<DailySummary[]>(() => {
    const saved = localStorage.getItem('nudge_history');
    return saved ? JSON.parse(saved) : [];
  });

  const [workHours, setWorkHours] = useState<WorkHours>(() => {
    const saved = localStorage.getItem('nudge_work_hours');
    return saved ? JSON.parse(saved) : { start: '09:00', end: '18:00' };
  });

  const [simTime, setSimTime] = useState<string>(() => {
    return localStorage.getItem('nudge_sim_time') || '08:00';
  });

  const [simDay, setSimDay] = useState<number>(() => {
    const saved = localStorage.getItem('nudge_sim_day');
    return saved ? parseInt(saved, 10) : 1;
  });

  const [streakCount, setStreakCount] = useState<number>(() => {
    const saved = localStorage.getItem('nudge_streak');
    return saved ? parseInt(saved, 10) : 1;
  });

  // --- UI and App Flow State ---
  const [messages, setMessages] = useState<NudgeMessage[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [autoAdvance, setAutoAdvance] = useState(false);
  const [showAddTask, setShowAddTask] = useState(false);
  const [aiStatus, setAiStatus] = useState({ active: false, info: 'Connecting to server...' });
  const [notification, setNotification] = useState<{ id: string; text: string; type: 'info' | 'warning' | 'error' | 'success'; title: string } | null>(null);

  // --- Task addition form state ---
  const [newTaskName, setNewTaskName] = useState('');
  const [newTaskDeadline, setNewTaskDeadline] = useState('18:00');
  const [newTaskEffort, setNewTaskEffort] = useState('30m');
  const [newTaskCategory, setNewTaskCategory] = useState<TaskUrgency>('URGENT');
  const [formValidationError, setFormValidationError] = useState<string | null>(null);
  const [isAddingTaskLoading, setIsAddingTaskLoading] = useState(false);

  // --- Night Review Mode State ---
  const [nightReviewActive, setNightReviewActive] = useState(false);
  const [reviewStatuses, setReviewStatuses] = useState<Record<string, TaskOutcome>>({});

  // --- Planning Mode State ---
  const [planningModeActive, setPlanningModeActive] = useState(false);
  const [carryOverCandidates, setCarryOverCandidates] = useState<Task[]>([]);
  const [selectedCarryOvers, setSelectedCarryOvers] = useState<Record<string, boolean>>({});
  const [plannedTomorrowTasks, setPlannedTomorrowTasks] = useState<Task[]>([]);

  // --- Voice & Focus Mode State ---
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isFastVoiceListening, setIsFastVoiceListening] = useState(false);
  const [showVoiceHud, setShowVoiceHud] = useState(false);
  const [voiceHudType, setVoiceHudType] = useState<'chat' | 'task'>('chat');
  const [voiceHudTranscript, setVoiceHudTranscript] = useState('');
  const [voiceHudError, setVoiceHudError] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);
  const fastVoiceRecognitionRef = useRef<any>(null);

  const chatEndRef = useRef<HTMLDivElement>(null);
  const processedTouchpoints = useRef<Record<string, boolean>>({});

  // Save state helpers
  useEffect(() => {
    localStorage.setItem('nudge_active_tasks', JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem('nudge_history', JSON.stringify(history));
  }, [history]);

  useEffect(() => {
    localStorage.setItem('nudge_work_hours', JSON.stringify(workHours));
  }, [workHours]);

  useEffect(() => {
    localStorage.setItem('nudge_sim_time', simTime);
  }, [simTime]);

  useEffect(() => {
    localStorage.setItem('nudge_sim_day', String(simDay));
  }, [simDay]);

  useEffect(() => {
    localStorage.setItem('nudge_streak', String(streakCount));
  }, [streakCount]);

  // Reactive validation for task effort (min 10 mins, max based on deadline)
  useEffect(() => {
    if (!newTaskEffort) {
      setFormValidationError(null);
      return;
    }
    const effortMins = parseEffortToMinutes(newTaskEffort);
    const maxMins = getMinutesDiff(simTime, newTaskDeadline);

    if (effortMins < 10) {
      setFormValidationError(`Effort must be at least 10 minutes (You entered: ${effortMins}m).`);
    } else if (effortMins > maxMins) {
      setFormValidationError(`Effort cannot exceed the time left until the deadline (${maxMins}m). You entered: ${effortMins}m.`);
    } else {
      setFormValidationError(null);
    }
  }, [newTaskEffort, newTaskDeadline, simTime]);

  // Check backend and API status on load
  useEffect(() => {
    fetch('/api/ai-status')
      .then((res) => res.json())
      .then((data) => {
        setAiStatus({ active: data.active, info: data.info });
      })
      .catch((err) => {
        setAiStatus({ active: false, info: 'Heuristic Fallback Mode' });
      });
  }, []);

  // Set up Web Speech API recognition - handles browser/iframe context dynamically
  const handleToggleListening = () => {
    // Stop fast voice listening if active to avoid conflict
    if (isFastVoiceListening && fastVoiceRecognitionRef.current) {
      try {
        fastVoiceRecognitionRef.current.stop();
      } catch (e) {}
      setIsFastVoiceListening(false);
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setVoiceHudType('chat');
      setVoiceHudTranscript('Voice assist loaded in Simulated Mode.');
      setVoiceHudError('Web Speech API is unsupported on this browser/iframe. Try Google Chrome or use Simulated Mode below!');
      setShowVoiceHud(true);
      playChime('error');
      speakText("Voice assistant ready in simulated mode.", voiceEnabled);
      return;
    }

    if (isListening) {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {}
      }
      setIsListening(false);
      setShowVoiceHud(false);
      playChime('error');
      return;
    }

    try {
      const rec = new SpeechRecognition();
      rec.continuous = false;
      rec.interimResults = false;
      rec.lang = 'en-US';

      rec.onstart = () => {
        setIsListening(true);
        setVoiceHudType('chat');
        setVoiceHudTranscript('Listening for command...');
        setVoiceHudError(null);
        setShowVoiceHud(true);
        
        playChime('start');
        speakText("I am listening.", voiceEnabled);
      };

      rec.onend = () => {
        setIsListening(false);
      };

      rec.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setChatInput(transcript);
        setVoiceHudTranscript(`"${transcript}"`);
        
        playChime('success');
        speakText(`Heard: ${transcript}`, voiceEnabled);
        
        setTimeout(() => {
          setShowVoiceHud(false);
        }, 1500);
      };

      rec.onerror = (err: any) => {
        console.error("Speech Recognition Error:", err);
        setIsListening(false);
        playChime('error');
        
        let friendlyMessage = "Sorry, I couldn't hear that. Please try again or type/select a prompt below.";
        if (err.error === 'not-allowed') {
          friendlyMessage = "Microphone access blocked. Click the 'Open in New Tab' button on top of AI Studio to grant mic permissions, or use Simulated Mode below!";
        }
        setVoiceHudError(friendlyMessage);
        setVoiceHudTranscript('');
        speakText("Microphone restricted. You can type or select a shortcut instead.", voiceEnabled);
      };

      recognitionRef.current = rec;
      rec.start();
    } catch (e) {
      console.error("Could not construct or start SpeechRecognition:", e);
      setIsListening(false);
      setVoiceHudType('chat');
      setVoiceHudTranscript('Voice assistant is ready in simulated mode.');
      setVoiceHudError('Microphone block detected. Use the buttons below to simulate speaking!');
      setShowVoiceHud(true);
      playChime('error');
      speakText("Simulated voice assistant ready.", voiceEnabled);
    }
  };

  const handleFastVoiceAddTask = () => {
    // Stop chat listening if active to avoid conflict
    if (isListening && recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {}
      setIsListening(false);
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setVoiceHudType('task');
      setVoiceHudTranscript('Voice Quick-Add active in Simulated Mode.');
      setVoiceHudError('Web Speech API is unsupported on this browser/iframe. Try Google Chrome or use Simulated Mode below!');
      setShowVoiceHud(true);
      playChime('error');
      speakText("Voice assistant ready in simulated mode.", voiceEnabled);
      return;
    }

    if (isFastVoiceListening) {
      if (fastVoiceRecognitionRef.current) {
        try {
          fastVoiceRecognitionRef.current.stop();
        } catch (e) {}
      }
      setIsFastVoiceListening(false);
      setShowVoiceHud(false);
      playChime('error');
      return;
    }

    try {
      const rec = new SpeechRecognition();
      rec.continuous = false;
      rec.interimResults = false;
      rec.lang = 'en-US';

      rec.onstart = () => {
        setIsFastVoiceListening(true);
        setVoiceHudType('task');
        setVoiceHudTranscript('Listening for new agenda task...');
        setVoiceHudError(null);
        setShowVoiceHud(true);
        
        playChime('start');
        speakText("Tell me your new task.", voiceEnabled);
      };

      rec.onend = () => {
        setIsFastVoiceListening(false);
      };

      rec.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        
        setVoiceHudTranscript(`Captured task: "${transcript}"`);
        playChime('success');
        
        // Open form and fill with spoken task description
        setShowAddTask(true);
        setNewTaskName(transcript);
        
        // Dynamic deadline: current sim time + 2 hours (or fallback)
        const [hStr, mStr] = simTime.split(':');
        const h = (parseInt(hStr, 10) + 2) % 24;
        const defaultDeadline = `${String(h).padStart(2, '0')}:${mStr}`;
        setNewTaskDeadline(defaultDeadline);
        
        // Defaults
        setNewTaskEffort('30m');
        setNewTaskCategory('URGENT');
        setFormValidationError(null);

        speakText(`Adding task: ${transcript}. Choose effort and urgency category.`, voiceEnabled);
        
        setTimeout(() => {
          setShowVoiceHud(false);
        }, 1500);
      };

      rec.onerror = (err: any) => {
        console.error("Fast Voice Speech Error:", err);
        setIsFastVoiceListening(false);
        playChime('error');
        
        let friendlyMessage = "Sorry, I couldn't hear that task. Try again, or type/simulate below!";
        if (err.error === 'not-allowed') {
          friendlyMessage = "Microphone access blocked. Click the 'Open in New Tab' button on top of AI Studio to grant mic permissions, or use Simulated Mode below!";
        }
        setVoiceHudError(friendlyMessage);
        setVoiceHudTranscript('');
        speakText("Microphone restricted. You can type or select a shortcut instead.", voiceEnabled);
      };

      fastVoiceRecognitionRef.current = rec;
      rec.start();
    } catch (e) {
      console.error("Could not construct or start speech recognition:", e);
      setIsFastVoiceListening(false);
      setVoiceHudType('task');
      setVoiceHudTranscript('Voice Quick-Add ready in Simulated Mode.');
      setVoiceHudError('Microphone block detected. Use the buttons below to simulate speaking!');
      setShowVoiceHud(true);
      playChime('error');
      speakText("Simulated voice assistant ready.", voiceEnabled);
    }
  };

  // Set up morning welcome message on day load or empty chat
  useEffect(() => {
    if (messages.length === 0) {
      triggerMorningGreeting();
    }
  }, [simDay]);

  // Scroll to bottom of chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // ---------------------------------------------------------
  // Automatic Time Advance Simulation Interval
  // ---------------------------------------------------------
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (autoAdvance) {
      interval = setInterval(() => {
        handleAdvanceOneHour();
      }, 7000); // 7 seconds simulated time leap
    }
    return () => clearInterval(interval);
  }, [autoAdvance, simTime]);

  // ---------------------------------------------------------
  // Core Touchpoint Rules & Time Trigger Checkers
  // ---------------------------------------------------------
  useEffect(() => {
    // Generate unique key for this day + time to prevent multiple pings
    const timeKey = `day_${simDay}_time_${simTime}`;
    if (processedTouchpoints.current[timeKey]) return;

    const [hour, min] = simTime.split(':').map((n) => parseInt(n, 10));

    // Shift check-in hours based on user preference
    const isDefault = workHours.start === '09:00' && workHours.end === '18:00';
    let t1 = 12, t2 = 15, t3 = 17, tEodHour = 22, tEodMin = 30, tReview = 21;
    
    if (!isDefault) {
      const startH = parseInt(workHours.start.split(':')[0], 10);
      const endH = parseInt(workHours.end.split(':')[0], 10);
      const endM = parseInt(workHours.end.split(':')[1] || '0', 10);
      const span = (endH - startH + 24) % 24;

      t1 = (startH + Math.round(span * 0.33)) % 24;
      t2 = (startH + Math.round(span * 0.66)) % 24;
      t3 = (startH + Math.round(span * 0.90)) % 24;
      tEodHour = endH;
      tEodMin = endM;
      tReview = (endH + 1) % 24;
    }

    // 1. Check-In #1: Low-Urgency / Day-End check (12:00 PM standard)
    if (hour === t1 && min === 0) {
      processedTouchpoints.current[timeKey] = true;
      triggerTouchpointCheckIn('12:00 PM', 'DAY_END');
    }

    // 2. Check-In #2: Urgent status check (3:00 PM standard)
    if (hour === t2 && min === 0) {
      processedTouchpoints.current[timeKey] = true;
      triggerTouchpointCheckIn('3:00 PM', 'URGENT');
    }

    // 3. Check-In #3: Very Urgent status check (5:45 / 6:00 PM standard)
    if (hour === t3 && min === 0) {
      processedTouchpoints.current[timeKey] = true;
      triggerTouchpointCheckIn('6:00 PM', 'VERY_URGENT');
    }

    // 4. Check-In #4: Final EOD Deadline Alarm (End of shift / EOD)
    if (hour === tEodHour && min === tEodMin) {
      processedTouchpoints.current[timeKey] = true;
      triggerDeadlineFailsafe();
    }

    // 5. Night Review (9:30 PM / after shift end)
    if (hour === tReview && min === 0) {
      processedTouchpoints.current[timeKey] = true;
      triggerNightReviewTouchpoint();
    }

    // Check individual task deadline breaches dynamically
    checkTaskDeadlineBreaches(simTime);

  }, [simTime, simDay, tasks, workHours]);

  // ---------------------------------------------------------
  // Action Handlers & Schedulers
  // ---------------------------------------------------------

  // Morning Greetings
  const triggerMorningGreeting = () => {
    const listText = tasks.map(t => `- **${t.name}** [${t.category === 'VERY_URGENT' ? 'Very Urgent' : t.category === 'URGENT' ? 'Urgent' : 'Day-End'}] due at ${t.deadline}`).join('\n');
    
    setMessages([
      {
        id: `morning_greet_${Date.now()}`,
        sender: 'AI',
        text: `🌅 Good morning! Ready for **Day ${simDay}**? I have structured and prioritized today's agenda for you.

Here is your Active Task List:
${listText || "*No tasks added yet. Let's add some!*"}

${tasks.length > 0 ? "Let's work through these deadlines collectively today. I will monitor progress and nudge you when appropriate!" : "Use the task creator to add items, and I will auto-classify their urgency immediately."}`,
        timestamp: `Day ${simDay} - 08:00 AM`,
        type: 'SYSTEM'
      }
    ]);
  };

  // Touchpoint Check-Ins
  const triggerTouchpointCheckIn = async (checkInLabel: string, category: TaskUrgency) => {
    const pendingTasks = tasks.filter(t => t.category === category && t.outcome === 'PENDING');
    if (pendingTasks.length === 0) return;

    // Grab the first pending task of this urgency class
    const taskToNudge = pendingTasks[0];

    setIsTyping(true);
    try {
      const response = await fetch('/api/nudge/generate-nudge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ task: taskToNudge, checkInTime: checkInLabel, workHours }),
      });
      const data = await response.json();
      
      addAIMessage(
        data.text,
        'NUDGE',
        [`Mark "${taskToNudge.name}" Completed`, `Snooze 1hr`, `Defer tomorrow`]
      );

      setNotification({
        id: `notif_${Date.now()}`,
        title: `${category.replace('_', ' ')} Alert`,
        text: `Nudge check-in: ${taskToNudge.name}`,
        type: category === 'VERY_URGENT' ? 'error' : category === 'URGENT' ? 'warning' : 'info'
      });
    } catch (e) {
      console.error(e);
    } finally {
      setIsTyping(false);
    }
  };

  // EOD Hard Deadline Alarm
  const triggerDeadlineFailsafe = () => {
    const pendingUrgent = tasks.filter(t => t.outcome === 'PENDING' && (t.category === 'VERY_URGENT' || t.category === 'URGENT'));
    if (pendingUrgent.length === 0) return;

    const listText = pendingUrgent.map(t => `• "${t.name}" (due at ${t.deadline})`).join('\n');
    
    addAIMessage(
      `🔔 **CRITICAL DEADLINE FAILSALFE ALARM** 🔔
The simulated working shift has reached its deadline. You have ${pendingUrgent.length} urgent tasks still marked incomplete:
${listText}

Please tackle these immediately. What would you like to do with them?`,
      'ALARM',
      [`Complete All`, `Snooze All`, `Carry to Tomorrow`]
    );

    setNotification({
      id: `alarm_${Date.now()}`,
      title: '🔔 DEADLINE FAILSALFE',
      text: `${pendingUrgent.length} crucial deadlines are expiring! Action required.`,
      type: 'error'
    });
  };

  // Night Review Initialization
  const triggerNightReviewTouchpoint = () => {
    setNightReviewActive(true);
    
    // Seed initial review answers
    const initialStatuses: Record<string, TaskOutcome> = {};
    tasks.forEach(t => {
      // If completed (marked ON_TIME / IN_PROCESS), pre-populate, else set to pending for user select
      initialStatuses[t.id] = t.outcome;
    });
    setReviewStatuses(initialStatuses);

    addAIMessage(
      `🌙 **It's 09:30 PM: Night Review Hour**
Today's simulated shift has concluded. Let's review the outcomes to structure tomorrow's loop.

Please confirm the status of your tasks in the feedback panel. Once verified, we will generate the pattern diagnostic summary!`,
      'REVIEW'
    );
  };

  // Check if current hour matched any specific task deadline
  const checkTaskDeadlineBreaches = (currentTime: string) => {
    tasks.forEach(t => {
      if (t.outcome === 'PENDING') {
        if (t.deadline === currentTime) {
          // Soft chime alarm
          setNotification({
            id: `alarm_t_${t.id}_${Date.now()}`,
            title: '🔔 Task Deadline',
            text: `"${t.name}" is due right now (${t.deadline})!`,
            type: 'warning'
          });
          speakText(`Attention! The deadline for task: ${t.name} is due now!`, voiceEnabled);
        }

        // 30 mins remaining warning
        const currentMins = timeToMinutes(currentTime);
        const deadlineMins = timeToMinutes(t.deadline);
        const remaining = deadlineMins - currentMins;
        
        if (remaining > 0 && remaining <= 30 && !t.notified30m) {
          speakText(`30 more minutes left to finish the task: ${t.name}`, voiceEnabled);
          
          setNotification({
            id: `assistant_speech_${t.id}_${Date.now()}`,
            title: 'Female Assistant Alert',
            text: `30 more minutes left to finish "${t.name}"!`,
            type: 'warning'
          });
          
          setTasks(prev =>
            prev.map(taskItem => {
              if (taskItem.id === t.id) {
                return { ...taskItem, notified30m: true };
              }
              return taskItem;
            })
          );
        }
      }
    });
  };

  // Add message helper
  const addAIMessage = (text: string, type: NudgeMessage['type'] = 'CHAT', quickReplies?: string[], metadata?: any) => {
    setMessages(prev => [
      ...prev,
      {
        id: `ai_${Date.now()}`,
        sender: 'AI',
        text,
        timestamp: `Day ${simDay} - ${formatTime12h(simTime)}`,
        type,
        quickReplies,
        metadata
      }
    ]);
  };

  const addUserMessage = (text: string) => {
    setMessages(prev => [
      ...prev,
      {
        id: `user_${Date.now()}`,
        sender: 'USER',
        text,
        timestamp: `Day ${simDay} - ${formatTime12h(simTime)}`,
        type: 'CHAT'
      }
    ]);
  };

  // Helper 12h formatting
  const formatTime12h = (time24: string) => {
    const [hStr, mStr] = time24.split(':');
    const h = parseInt(hStr, 10);
    const ampm = h >= 12 ? 'PM' : 'AM';
    const displayH = h % 12 === 0 ? 12 : h % 12;
    return `${displayH}:${mStr} ${ampm}`;
  };

  // Focus Mode Incrementation and Auto-Complete
  const incrementFocusedTaskTime = (minutesToAdd: number, currentTime: string) => {
    setTasks(prev =>
      prev.map(t => {
        if (t.isFocused && t.outcome === 'PENDING') {
          const currentSpent = t.timeSpent || 0;
          const nextSpent = currentSpent + minutesToAdd;
          const effortMins = parseEffortToMinutes(t.estimatedEffort);
          
          if (nextSpent >= effortMins) {
            setNotification({
              id: `autocomp_${t.id}_${Date.now()}`,
              title: '🎉 Task Completed!',
              text: `"${t.name}" was automatically marked completed after spending ${nextSpent}m of focus!`,
              type: 'success'
            });
            speakText(`Congratulations! You have completed your task: ${t.name}! Great job.`, voiceEnabled);
            
            return {
              ...t,
              timeSpent: nextSpent,
              isFocused: false,
              outcome: 'ON_TIME',
              completedAtSimTime: getRealTime24h()
            };
          }
          
          return {
            ...t,
            timeSpent: nextSpent
          };
        }
        return t;
      })
    );
  };

  const handleToggleFocus = (id: string) => {
    setTasks(prev =>
      prev.map(t => {
        if (t.id === id) {
          const nextFocused = !t.isFocused;
          if (nextFocused) {
            setNotification({
              id: `focus_start_${id}`,
              title: '🎯 Focus Mode Initiated',
              text: `Now focusing on "${t.name}". Keep advancing time to accrue progress!`,
              type: 'success'
            });
            speakText(`Focusing on task: ${t.name}. Let's lock in and get this done!`, voiceEnabled);
          } else {
            setNotification({
              id: `focus_stop_${id}`,
              title: 'Focus Paused',
              text: `Focused session paused for "${t.name}".`,
              type: 'info'
            });
          }
          return { ...t, isFocused: nextFocused };
        }
        return { ...t, isFocused: false }; // only allow one active task
      })
    );
  };

  // Time Advancer
  const handleAdvanceOneHour = () => {
    setSimTime(prev => {
      const [hStr, mStr] = prev.split(':');
      let h = parseInt(hStr, 10);
      let m = parseInt(mStr, 10);
      
      h = (h + 1) % 24;
      const nextTime = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
      
      // Advance focused task progress by 60 mins
      incrementFocusedTaskTime(60, nextTime);
      
      return nextTime;
    });
  };

  const handleSetTime = (newTime: string) => {
    const diffMins = getMinutesDiff(simTime, newTime);
    if (diffMins > 0) {
      incrementFocusedTaskTime(diffMins, newTime);
    }
    
    setSimTime(newTime);
    setNotification({
      id: `time_set_${Date.now()}`,
      title: 'Time Travel Active',
      text: `Simulated clock updated to ${formatTime12h(newTime)}`,
      type: 'info'
    });
  };

  // ---------------------------------------------------------
  // Chat Engine & Quick Action Triggers
  // ---------------------------------------------------------
  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!chatInput.trim()) return;

    const userText = chatInput;
    addUserMessage(userText);
    setChatInput('');
    setIsTyping(true);

    try {
      // Natural language task parser / chatbot response
      const lower = userText.toLowerCase();

      if (lower.startsWith('add ') || lower.includes('remind me to') || lower.includes('task:')) {
        // Add task request
        let taskName = userText.replace(/add /i, '').replace(/remind me to /i, '');
        let deadline = '18:00';
        let effort = '30m';

        // Extract deadline e.g. "at 16:00"
        const timeMatch = taskName.match(/(?:at|by|due) (\d{1,2}:\d{2})/i);
        if (timeMatch) {
          deadline = timeMatch[1];
          taskName = taskName.replace(/(?:at|by|due) \d{1,2}:\d{2}/i, '');
        }

        // Extract effort e.g. "for 2 hours"
        const effortMatch = taskName.match(/(?:for) (\d+)\s*(mins?|hours?|h|m)/i);
        if (effortMatch) {
          effort = `${effortMatch[1]}${effortMatch[2].substring(0, 1)}`;
          taskName = taskName.replace(/(?:for) \d+\s*(mins?|hours?|h|m)/i, '');
        }

        taskName = taskName.trim().replace(/^"/, '').replace(/"$/, '');

        // Call server classify
        const response = await fetch('/api/nudge/classify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: taskName, deadline, estimatedEffort: effort }),
        });
        const classified = await response.json();

        const newTask: Task = {
          id: `task_${Date.now()}`,
          name: classified.name,
          deadline: classified.deadline,
          estimatedEffort: classified.estimatedEffort,
          category: classified.category,
          outcome: 'PENDING',
          carriedOver: false,
          bumpedCount: 0,
          consequence: classified.consequence,
          actionSuggestion: classified.actionSuggestion
        };

        setTasks(prev => [...prev, newTask]);
        addAIMessage(
          `✅ **Task added and categorized!**
- **Task:** "${newTask.name}"
- **Urgency:** ${newTask.category.replace('_', ' ')}
- **Consequence framing:** ${newTask.consequence}
- **Starting action suggestion:** ${newTask.actionSuggestion}`,
          'SYSTEM'
        );
      } else {
        // Conversational response from Gemini / fallback
        const response = await fetch('/api/nudge/generate-nudge', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            task: tasks[0] || { name: 'Your agenda', category: 'URGENT', consequence: 'Keeping your day on track', actionSuggestion: 'Stay active' },
            checkInTime: 'Conversational Ask',
            workHours
          }),
        });
        const data = await response.json();
        
        addAIMessage(
          data.text + `\n\n*(You can add a task anytime by typing: "Add [task name] by [HH:MM] for [duration]")*`
        );
      }
    } catch (err) {
      console.error(err);
      addAIMessage("I'm here to assist you. To schedule a new task, type: 'Add [task] by [deadline]'.");
    } finally {
      setIsTyping(false);
    }
  };

  const handleQuickReply = (replyText: string) => {
    addUserMessage(replyText);
    setIsTyping(true);

    setTimeout(() => {
      const lower = replyText.toLowerCase();

      if (lower.includes('mark') && lower.includes('completed')) {
        // Find task matching the quote
        const match = replyText.match(/"([^"]+)"/);
        const taskToComplete = match ? tasks.find(t => t.name.toLowerCase().includes(match[1].toLowerCase())) : tasks[0];
        if (taskToComplete) {
          handleToggleComplete(taskToComplete.id);
          addAIMessage(`Fantastic! "${taskToComplete.name}" has been completed. Striving forward.`);
        } else {
          addAIMessage("Which task would you like to check off?");
        }
      } else if (lower.includes('snooze')) {
        addAIMessage("Snoozed. I will check in again on your pending agenda items shortly.");
      } else if (lower.includes('defer') || lower.includes('carry')) {
        addAIMessage("Understood. We will register this task as a carrying-over candidate for tomorrow's loop.");
      } else if (lower.includes('complete all')) {
        setTasks(prev => prev.map(t => ({ ...t, outcome: 'ON_TIME', completedAtSimTime: getRealTime24h() })));
        addAIMessage("Superb! All pending tasks have been checked off.");
      } else {
        addAIMessage("Command logged. Let's keep driving today's commitments.");
      }
      setIsTyping(false);
    }, 1000);
  };

  // ---------------------------------------------------------
  // Task Manipulation Logic
  // ---------------------------------------------------------
  const handleToggleComplete = (id: string) => {
    setTasks(prev =>
      prev.map(t => {
        if (t.id === id) {
          const isComp = t.outcome === 'ON_TIME' || t.outcome === 'IN_PROCESS';
          return {
            ...t,
            outcome: isComp ? 'PENDING' : 'ON_TIME',
            completedAtSimTime: isComp ? undefined : getRealTime24h()
          };
        }
        return t;
      })
    );
  };

  const handleSnooze = (id: string) => {
    setTasks(prev =>
      prev.map(t => {
        if (t.id === id) {
          // Add 1 hour to deadline
          const [hStr, mStr] = t.deadline.split(':');
          const newH = (parseInt(hStr, 10) + 1) % 24;
          const newDeadline = `${String(newH).padStart(2, '0')}:${mStr}`;
          
          setNotification({
            id: `snooze_${id}`,
            title: 'Task Snoozed',
            text: `"${t.name}" deadline postponed to ${newDeadline}`,
            type: 'info'
          });
          
          return { ...t, deadline: newDeadline };
        }
        return t;
      })
    );
  };

  const handleMoveTomorrow = (id: string) => {
    const taskToMove = tasks.find(t => t.id === id);
    if (!taskToMove) return;

    // Remove from active list and append to carry over candidates
    setTasks(prev => prev.filter(t => t.id !== id));
    
    // Auto upgrade category urgency for next day
    let bumpedCategory = taskToMove.category;
    if (bumpedCategory === 'DAY_END') bumpedCategory = 'URGENT';
    else if (bumpedCategory === 'URGENT') bumpedCategory = 'VERY_URGENT';

    const carriedTask: Task = {
      ...taskToMove,
      category: bumpedCategory,
      carriedOver: true,
      bumpedCount: taskToMove.bumpedCount + 1,
      outcome: 'PENDING'
    };

    setCarryOverCandidates(prev => [...prev, carriedTask]);
    
    addAIMessage(
      `↪️ Task "${taskToMove.name}" has been deferred. It will be carried over to tomorrow's list with **bumped urgency** (${bumpedCategory.replace('_', ' ')}).`,
      'SYSTEM'
    );
  };

  const handleAddTaskSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskName.trim()) return;

    // Effort Validation: Min 10 minutes, Max based on task deadline remaining minutes
    const effortMins = parseEffortToMinutes(newTaskEffort);
    const maxMins = getMinutesDiff(simTime, newTaskDeadline);

    if (effortMins < 10) {
      const errMsg = `Effort must be at least 10 minutes. You entered: ${effortMins}m.`;
      setFormValidationError(errMsg);
      speakText(errMsg, voiceEnabled);
      return;
    }

    if (effortMins > maxMins) {
      const errMsg = `Effort (${effortMins}m) cannot exceed the time left until the deadline (${maxMins}m).`;
      setFormValidationError(errMsg);
      speakText(errMsg, voiceEnabled);
      return;
    }

    // Clear any previous error
    setFormValidationError(null);
    setIsAddingTaskLoading(true);

    try {
      const response = await fetch('/api/nudge/classify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newTaskName, deadline: newTaskDeadline, estimatedEffort: newTaskEffort }),
      });
      const data = await response.json();

      // Respect user's custom chosen category / manual categorization
      const finalCategory = newTaskCategory;

      const newTask: Task = {
        id: `task_${Date.now()}`,
        name: data.name,
        deadline: data.deadline,
        estimatedEffort: data.estimatedEffort,
        category: finalCategory, // Custom user manual category override
        outcome: 'PENDING',
        carriedOver: false,
        bumpedCount: 0,
        consequence: data.consequence || "Custom planned commitment",
        actionSuggestion: data.actionSuggestion || "Get started in a quiet workspace."
      };

      if (planningModeActive) {
        setPlannedTomorrowTasks(prev => [...prev, newTask]);
      } else {
        setTasks(prev => [...prev, newTask]);
        addAIMessage(
          `📝 **Added new task!**
- **Task:** "${newTask.name}"
- **Manual Category:** **${newTask.category.replace('_', ' ')}** (categorized per your preference)
- **Effort Duration:** ${newTask.estimatedEffort} (${effortMins}m)
- **Consequence framing:** ${newTask.consequence}
- **Nudge Advice:** ${newTask.actionSuggestion}`,
          'SYSTEM'
        );
      }

      setNewTaskName('');
      setShowAddTask(false);
    } catch (err) {
      console.error(err);
    } {
      setIsAddingTaskLoading(false);
    }
  };

  // ---------------------------------------------------------
  // Night Review & Planning Transition Flow
  // ---------------------------------------------------------
  const handleReviewStatusSelect = (taskId: string, outcome: TaskOutcome) => {
    setReviewStatuses(prev => ({ ...prev, [taskId]: outcome }));
  };

  const handleFinalizeNightReview = async () => {
    // 1. Map outcomes back to current tasks
    const finalizedTasks = tasks.map(t => {
      const selectedOutcome = reviewStatuses[t.id] || 'MISSED';
      const isCompletedNow = selectedOutcome === 'ON_TIME' || selectedOutcome === 'IN_PROCESS';
      return {
        ...t,
        outcome: selectedOutcome,
        completedAtSimTime: isCompletedNow ? (t.completedAtSimTime || getRealTime24h()) : undefined
      };
    });

    setTasks(finalizedTasks);

    // 2. Count outcomes
    const onTimeCount = finalizedTasks.filter(t => t.outcome === 'ON_TIME').length;
    const inProcessCount = finalizedTasks.filter(t => t.outcome === 'IN_PROCESS').length;
    const missedCount = finalizedTasks.filter(t => t.outcome === 'MISSED').length;

    // Adjust streak count based on completed tasks
    if (onTimeCount > 0 && missedCount === 0) {
      setStreakCount(prev => prev + 1);
    } else if (onTimeCount === 0 && missedCount > 0) {
      setStreakCount(1); // Reset streak
    }

    // 3. Trigger pattern analysis via API
    setIsTyping(true);
    let aiSummary = "Splendid day of logging. Keep maintaining consistency!";
    let recommendedFix = "";
    
    try {
      const response = await fetch('/api/nudge/pattern-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          history: [...history, { day: simDay, tasksSnapshot: finalizedTasks } as any],
          currentTasks: finalizedTasks
        }),
      });
      const analysisData = await response.json();
      aiSummary = analysisData.analysis;
      recommendedFix = analysisData.suggestedFix;
    } catch (e) {
      console.error(e);
    }

    // 4. Save to history
    const summary: DailySummary = {
      day: simDay,
      dateString: new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' }),
      onTimeCount,
      inProcessCount,
      missedCount,
      tasksSnapshot: finalizedTasks,
      aiAnalysis: aiSummary
    };

    setHistory(prev => [...prev, summary]);

    // 5. Gather carry-over candidates (In Process and Missed automatically)
    const carryOvers = finalizedTasks.filter(t => t.outcome === 'IN_PROCESS' || t.outcome === 'MISSED');
    
    // Bump urgency level for carry-overs
    const upgradedCarryOvers = carryOvers.map(t => {
      let bumpedCategory = t.category;
      if (bumpedCategory === 'DAY_END') bumpedCategory = 'URGENT';
      else if (bumpedCategory === 'URGENT') bumpedCategory = 'VERY_URGENT';
      
      return {
        ...t,
        category: bumpedCategory,
        carriedOver: true,
        bumpedCount: t.bumpedCount + 1,
        outcome: 'PENDING' as TaskOutcome
      };
    });

    setCarryOverCandidates(upgradedCarryOvers);
    
    // Auto select carry overs
    const initialSelections: Record<string, boolean> = {};
    upgradedCarryOvers.forEach(t => {
      initialSelections[t.id] = true;
    });
    setSelectedCarryOvers(initialSelections);

    setNightReviewActive(false);
    setPlanningModeActive(true);
    setPlannedTomorrowTasks([]);

    addAIMessage(
      `📊 **Day ${simDay} Review Completed**
- **Summary:** ${onTimeCount} On Time, ${inProcessCount} In Process, ${missedCount} Missed.
- **AI Feedback:** ${aiSummary}

Let's plan for **Day ${simDay + 1}**. What do you need to get done tomorrow?`,
      'PLANNING'
    );
    setIsTyping(false);
  };

  const handleToggleCarryOverSelect = (id: string) => {
    setSelectedCarryOvers(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handleInitiateNextDay = () => {
    // Collect selected carry overs
    const chosenCarryOvers = carryOverCandidates.filter(t => selectedCarryOvers[t.id]);
    
    // Combine with newly planned tomorrow tasks
    const tomorrowTasks = [...chosenCarryOvers, ...plannedTomorrowTasks];

    // Transition state
    setTasks(tomorrowTasks);
    setSimDay(prev => prev + 1);
    setSimTime('08:00');
    setPlanningModeActive(false);
    setCarryOverCandidates([]);
    setPlannedTomorrowTasks([]);

    setNotification({
      id: `new_day_${Date.now()}`,
      title: '🌅 New Loop Initiated',
      text: `Welcome to Day ${simDay + 1}! Let's lock in and conquer these commitments.`,
      type: 'success'
    });
  };

  const handleApplyStructuralFix = (fixText: string) => {
    setNotification({
      id: `fix_applied_${Date.now()}`,
      title: 'Structural Fix Applied',
      text: 'Rescheduled and updated target work periods for future loops.',
      type: 'success'
    });
    // Append systemic action tips to tasks
    setTasks(prev => prev.map(t => {
      if (t.category === 'URGENT' || t.category === 'VERY_URGENT') {
        return {
          ...t,
          actionSuggestion: `${t.actionSuggestion} (Structural adjustment: Done in blocks).`
        };
      }
      return t;
    }));
  };

  const handleResetSimulation = () => {
    setTasks(INITIAL_TASKS);
    setHistory([]);
    setStreakCount(1);
    setSimDay(1);
    setSimTime('08:00');
    setMessages([]);
    setCarryOverCandidates([]);
    setPlannedTomorrowTasks([]);
    setPlanningModeActive(false);
    setNightReviewActive(false);
    processedTouchpoints.current = {};
    localStorage.removeItem('nudge_active_tasks');
    localStorage.removeItem('nudge_history');
    localStorage.removeItem('nudge_streak');
    localStorage.removeItem('nudge_sim_day');
    localStorage.removeItem('nudge_sim_time');
    triggerMorningGreeting();
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col antialiased">
      
      {/* Dynamic Sound Notification Banner */}
      <NotificationBanner
        notification={notification}
        onClose={() => setNotification(null)}
      />

      {/* App Settings Modal Overlay */}
      <AnimatePresence>
        {showSettings && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: -20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: -20 }}
              className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl relative space-y-6"
            >
              {/* Close Button */}
              <button
                onClick={() => setShowSettings(false)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white text-xs font-mono font-bold bg-slate-950 hover:bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-800 cursor-pointer transition"
              >
                Close
              </button>

              <div className="space-y-1.5">
                <h3 className="text-lg font-black text-white flex items-center gap-2">
                  <Settings className="h-5 w-5 text-indigo-400 animate-spin" style={{ animationDuration: '6s' }} />
                  Workspace Settings
                </h3>
                <p className="text-xs text-slate-400 font-mono">Configure or download your Nudge Co-Pilot workspace</p>
              </div>

              {/* Download Option Section */}
              <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 space-y-3">
                <div className="flex items-start gap-3">
                  <div className="p-2.5 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-lg">
                    <Download className="h-5 w-5" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-xs font-bold text-slate-200 font-mono uppercase tracking-wider">Download App Source</h4>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Package and download the entire application code bundle (Vite + React frontend and custom Node Express server) as a ZIP file to easily run locally.
                    </p>
                  </div>
                </div>

                <a
                  href="/api/download-app"
                  onClick={() => {
                    setNotification({
                      id: `app_download_${Date.now()}`,
                      title: 'Download Started',
                      text: 'Preparing and downloading application ZIP bundle...',
                      type: 'success'
                    });
                  }}
                  className="w-full flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black py-2.5 px-4 rounded-xl transition shadow-lg shadow-indigo-900/30 cursor-pointer"
                >
                  <Download className="h-4 w-4" />
                  Download Application ZIP
                </a>
              </div>

              {/* Voice Toggle Section */}
              <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 flex items-center justify-between">
                <div className="space-y-1 pr-4">
                  <h4 className="text-xs font-bold text-slate-200 font-mono uppercase tracking-wider">Voice Alerts</h4>
                  <p className="text-[11px] text-slate-400 leading-relaxed">Toggle spoken touchpoint alerts during simulation checkpoints.</p>
                </div>
                <button
                  onClick={() => {
                    const next = !voiceEnabled;
                    setVoiceEnabled(next);
                    if (next) speakText("Voice activated.", true);
                  }}
                  className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    voiceEnabled ? 'bg-indigo-600' : 'bg-slate-850'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                      voiceEnabled ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Reset Section */}
              <div className="bg-rose-950/10 border border-rose-500/10 rounded-xl p-4 space-y-3">
                <h4 className="text-xs font-bold text-rose-400 font-mono uppercase tracking-wider">Danger Zone</h4>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Resetting will wipe out all tasks, simulation history, streaks, and local state cache.
                </p>
                <button
                  onClick={() => {
                    if (confirm("Are you absolutely sure you want to reset all simulation data and start fresh?")) {
                      handleResetSimulation();
                      setShowSettings(false);
                    }
                  }}
                  className="w-full bg-rose-900/20 hover:bg-rose-900 border border-rose-500/20 hover:border-rose-400 text-rose-300 hover:text-white text-xs font-bold py-2 px-4 rounded-lg transition cursor-pointer text-center"
                >
                  Reset Local Database
                </button>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Main Header bar */}
      <header className="sticky top-0 z-40 bg-slate-900/80 backdrop-blur-md border-b border-slate-800 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="bg-gradient-to-tr from-indigo-500 to-emerald-400 p-2 rounded-xl text-slate-950 font-black tracking-tight flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <Sparkles className="h-5 w-5 stroke-[2.5]" />
          </div>
          <div>
            <h1 className="text-xl font-black tracking-tight flex items-center gap-1.5 text-white">
              Nudge
              <span className="text-[10px] font-black uppercase font-mono tracking-wider px-2 py-0.5 bg-indigo-950 text-indigo-300 rounded-full border border-indigo-500/30">
                Co-Pilot
              </span>
            </h1>
            <p className="text-xs text-slate-400 font-mono">Continuous Feedback Loop Planner</p>
          </div>
        </div>

        {/* Global Stats indicators */}
        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="bg-slate-950/60 px-3 py-1.5 rounded-xl border border-slate-800 flex items-center gap-2">
            <Calendar className="h-4 w-4 text-emerald-400" />
            <span>Simulated Date: <strong className="text-white">Day {simDay}</strong></span>
          </div>

          <div className="bg-slate-950/60 px-3 py-1.5 rounded-xl border border-slate-800 flex items-center gap-2">
            <Clock className="h-4 w-4 text-indigo-400" />
            <span>Time: <strong className="text-white">{formatTime12h(simTime)}</strong></span>
          </div>

          <button
            onClick={() => setShowSettings(!showSettings)}
            className={`p-1.5 rounded-xl border transition flex items-center justify-center cursor-pointer ${
              showSettings
                ? 'bg-indigo-950/60 border-indigo-500/40 text-indigo-400'
                : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
            }`}
            title="Workspace Settings"
          >
            <Settings className={`h-4.5 w-4.5 ${showSettings ? 'rotate-45' : ''} transition-transform duration-300`} />
          </button>
        </div>
      </header>

      {/* Dashboard container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left column (60%) - Core planner & interactive chat */}
        <section className="lg:col-span-7 flex flex-col gap-6 min-h-0">
          
          {/* Active touchpoints/tasks area */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col gap-4 shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-black text-white flex items-center gap-2">
                  <FileSpreadsheet className="h-4.5 w-4.5 text-emerald-400" />
                  Active Task Ledger
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">Urgency auto-adjusted on planning carry overs</p>
              </div>

              {/* Add Task Trigger */}
              <button
                onClick={() => setShowAddTask(!showAddTask)}
                className="flex items-center gap-1 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold py-1.5 px-3 rounded-lg transition shadow-md shadow-indigo-900/20 cursor-pointer"
              >
                <Plus className="h-3.5 w-3.5 stroke-[3]" />
                Add Task
              </button>

              {/* Quick Voice Add Task button */}
              <button
                type="button"
                onClick={handleFastVoiceAddTask}
                className={`flex items-center gap-1.5 text-xs font-bold py-1.5 px-3 rounded-lg border transition shadow-md cursor-pointer ${
                  isFastVoiceListening
                    ? 'bg-rose-950/60 border-rose-500 text-rose-400 animate-pulse'
                    : 'bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border-emerald-500/30 hover:text-white'
                }`}
                title="Speak a task description to quickly populate details"
              >
                {isFastVoiceListening ? (
                  <>
                    <MicOff className="h-3.5 w-3.5 text-rose-400" />
                    <span>Listening...</span>
                  </>
                ) : (
                  <>
                    <Mic className="h-3.5 w-3.5 text-emerald-400" />
                    <span>Voice Add (Fast)</span>
                  </>
                )}
              </button>
            </div>

            {/* Inline Task Form */}
            <AnimatePresence>
              {showAddTask && (
                <motion.form
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  onSubmit={handleAddTaskSubmit}
                  className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-4 overflow-hidden"
                >
                  <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono flex items-center gap-2">
                    <Sparkles className="h-3.5 w-3.5 text-emerald-400" />
                    New Agenda Item
                  </h3>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
                    <div className="sm:col-span-6">
                      <label className="block text-[10px] font-bold text-slate-500 uppercase font-mono mb-1">
                        Task description
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Pay utility bill, submit homework"
                        required
                        value={newTaskName}
                        onChange={(e) => setNewTaskName(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                      />
                    </div>

                    <div className="sm:col-span-3">
                      <label className="block text-[10px] font-bold text-slate-500 uppercase font-mono mb-1">
                        Deadline / Time
                      </label>
                      <input
                        type="time"
                        required
                        value={newTaskDeadline}
                        onChange={(e) => setNewTaskDeadline(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                      />
                    </div>

                    <div className="sm:col-span-3">
                      <label className="block text-[10px] font-bold text-slate-500 uppercase font-mono mb-1">
                        Effort (est)
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. 45m, 2h"
                        required
                        value={newTaskEffort}
                        onChange={(e) => setNewTaskEffort(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                      />
                      {/* Effort range helper info */}
                      <span className="text-[9px] text-indigo-450 font-mono block mt-1 leading-tight font-semibold">
                        Min: 10m | Max: {Math.max(10, getMinutesDiff(simTime, newTaskDeadline))}m (to deadline)
                      </span>
                    </div>
                  </div>

                  {/* Custom manual Category / Urgency selection */}
                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-bold text-slate-500 uppercase font-mono">
                      Task Urgency Category (Manual Choice)
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { value: 'VERY_URGENT', label: '🔥 Very Urgent', border: 'border-rose-500/30', text: 'text-rose-400', activeBg: 'bg-rose-950/40 text-rose-300 ring-2 ring-rose-550 border-rose-500/50' },
                        { value: 'URGENT', label: '⚡ Urgent', border: 'border-amber-500/30', text: 'text-amber-300', activeBg: 'bg-amber-950/40 text-amber-200 ring-2 ring-amber-550 border-amber-500/50' },
                        { value: 'DAY_END', label: '📅 Day-End', border: 'border-slate-800', text: 'text-slate-400', activeBg: 'bg-slate-850 text-slate-100 ring-2 ring-slate-650 border-slate-650' }
                      ].map(opt => (
                        <button
                          key={opt.value}
                          type="button"
                          onClick={() => setNewTaskCategory(opt.value as TaskUrgency)}
                          className={`px-3 py-2 text-[11px] font-extrabold rounded-lg border text-center transition cursor-pointer flex flex-col items-center justify-center gap-1 leading-tight ${
                            newTaskCategory === opt.value
                              ? opt.activeBg
                              : `bg-slate-900 ${opt.border} ${opt.text} hover:bg-slate-850 opacity-70`
                          }`}
                        >
                          <span>{opt.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {formValidationError && (
                    <div className="p-2.5 bg-rose-950/40 border border-rose-500/30 rounded-lg text-rose-300 text-[11px] leading-relaxed flex items-start gap-1.5 font-mono">
                      <span className="text-rose-400 font-bold">⚠️ Validation:</span>
                      <span>{formValidationError}</span>
                    </div>
                  )}

                  <div className="flex justify-end gap-2 text-xs font-semibold pt-1">
                    <button
                      type="button"
                      onClick={() => setShowAddTask(false)}
                      className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded text-slate-300 transition"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={isAddingTaskLoading}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 rounded text-white font-bold transition flex items-center gap-1"
                    >
                      {isAddingTaskLoading && <RefreshCw className="h-3 w-3 animate-spin" />}
                      Add & Categorize
                    </button>
                  </div>
                </motion.form>
              )}
            </AnimatePresence>

            {/* List of Tasks */}
            <div className="space-y-3 max-h-[340px] overflow-y-auto pr-1">
              {tasks.length === 0 ? (
                <div className="text-center py-10 border-2 border-dashed border-slate-800 rounded-xl text-slate-500 text-xs font-mono">
                  No active tasks for today. Click Add Task to log your commitments.
                </div>
              ) : (
                <>
                  {/* Categorized rendering: Very Urgent first */}
                  {tasks
                    .slice()
                    .sort((a, b) => {
                      const priority = { VERY_URGENT: 3, URGENT: 2, DAY_END: 1 };
                      return priority[b.category] - priority[a.category];
                    })
                    .map(task => (
                      <TaskItem
                        key={task.id}
                        task={task}
                        simTime={simTime}
                        onToggleComplete={handleToggleComplete}
                        onSnooze={handleSnooze}
                        onMoveTomorrow={handleMoveTomorrow}
                        onToggleFocus={handleToggleFocus}
                      />
                    ))}
                </>
              )}
            </div>
          </div>

          {/* Chat Panel */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl flex-1 flex flex-col overflow-hidden min-h-[420px] shadow-xl">
            {/* Header of Chat */}
            <div className="px-5 py-3.5 border-b border-slate-800 bg-slate-950/40 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-xs font-extrabold tracking-wide text-white uppercase font-mono">
                  Nudge AI Agent Feed
                </span>
              </div>
              <span className="text-[10px] text-slate-500 font-mono">
                Proactive Touchpoint Mode
              </span>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4 max-h-[380px]">
              {messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex flex-col max-w-[85%] ${
                    m.sender === 'USER' ? 'ml-auto items-end' : 'mr-auto items-start'
                  }`}
                >
                  <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-500 mb-1">
                    <span>{m.sender === 'AI' ? 'Nudge Co-Pilot' : 'You'}</span>
                    <span>•</span>
                    <span>{m.timestamp}</span>
                  </div>

                  <div
                    className={`p-3.5 rounded-2xl text-xs leading-relaxed ${
                      m.sender === 'USER'
                        ? 'bg-indigo-600 text-white rounded-tr-none'
                        : 'bg-slate-950 border border-slate-850 text-slate-200 rounded-tl-none font-medium'
                    }`}
                  >
                    {/* Render breaklines inside text */}
                    {m.text.split('\n').map((line, i) => (
                      <React.Fragment key={i}>
                        {line}
                        <br />
                      </React.Fragment>
                    ))}

                    {/* Planning / carry over selection panel inline inside chat if requested */}
                    {m.type === 'PLANNING' && carryOverCandidates.length > 0 && (
                      <div className="mt-4 p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-3">
                        <h4 className="text-[11px] font-bold text-slate-400 font-mono uppercase tracking-wider">
                          Carry Over Candidates from today
                        </h4>
                        <div className="space-y-2">
                          {carryOverCandidates.map(c => (
                            <label
                              key={c.id}
                              className="flex items-center gap-2.5 p-2 bg-slate-950 rounded-lg border border-slate-850 cursor-pointer text-[11px]"
                            >
                              <input
                                type="checkbox"
                                checked={selectedCarryOvers[c.id] || false}
                                onChange={() => handleToggleCarryOverSelect(c.id)}
                                className="rounded text-indigo-600 focus:ring-0 bg-slate-900 border-slate-700"
                              />
                              <div className="flex-1">
                                <p className="font-semibold text-slate-200">{c.name}</p>
                                <p className="text-[9px] text-slate-500">
                                  Bumped Urgency: <strong className="text-indigo-400">{c.category.replace('_', ' ')}</strong>
                                </p>
                              </div>
                            </label>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Night Review Interactive tap-to-confirm status board inside chat */}
                    {m.type === 'REVIEW' && nightReviewActive && (
                      <div className="mt-4 p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-3 text-slate-300">
                        <h4 className="text-[11px] font-bold text-indigo-400 font-mono uppercase tracking-wider">
                          Rate Task Outcomes:
                        </h4>
                        <div className="space-y-2.5">
                          {tasks.map((t) => (
                            <div key={t.id} className="p-2.5 bg-slate-950 rounded-xl border border-slate-850 space-y-2">
                              <p className="font-bold text-[11px] text-slate-200">{t.name}</p>
                              <div className="grid grid-cols-3 gap-1.5 text-[9px] font-mono">
                                <button
                                  onClick={() => handleReviewStatusSelect(t.id, 'ON_TIME')}
                                  className={`py-1 rounded font-bold transition ${
                                    reviewStatuses[t.id] === 'ON_TIME'
                                      ? 'bg-emerald-600 text-white'
                                      : 'bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-400'
                                  }`}
                                >
                                  On Time
                                </button>
                                <button
                                  onClick={() => handleReviewStatusSelect(t.id, 'IN_PROCESS')}
                                  className={`py-1 rounded font-bold transition ${
                                    reviewStatuses[t.id] === 'IN_PROCESS'
                                      ? 'bg-amber-600 text-white'
                                      : 'bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-400'
                                  }`}
                                >
                                  In Process
                                </button>
                                <button
                                  onClick={() => handleReviewStatusSelect(t.id, 'MISSED')}
                                  className={`py-1 rounded font-bold transition ${
                                    reviewStatuses[t.id] === 'MISSED'
                                      ? 'bg-rose-600 text-white'
                                      : 'bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-400'
                                  }`}
                                >
                                  Missed
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>

                        <button
                          onClick={handleFinalizeNightReview}
                          className="w-full mt-2 py-2 rounded bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-extrabold transition cursor-pointer"
                        >
                          Submit Reviews & Complete Day {simDay}
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Inline quick replies */}
                  {m.quickReplies && m.quickReplies.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1.5 max-w-full">
                      {m.quickReplies.map((qr, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleQuickReply(qr)}
                          className="px-3 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[11px] text-indigo-400 hover:text-white font-semibold transition"
                        >
                          {qr}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))}

              {/* Bot thinking indicator */}
              {isTyping && (
                <div className="mr-auto items-start max-w-[85%]">
                  <div className="text-[10px] font-mono text-slate-500 mb-1">Nudge is typing...</div>
                  <div className="bg-slate-950 border border-slate-850 p-3 rounded-2xl rounded-tl-none flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce" />
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce [animation-delay:0.2s]" />
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce [animation-delay:0.4s]" />
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            {/* Chat Control / input area */}
            <div className="p-3 bg-slate-950/60 border-t border-slate-800">
              {planningModeActive ? (
                <div className="p-3 bg-emerald-950/20 border border-emerald-500/30 rounded-xl space-y-3 flex flex-col text-slate-200">
                  <div className="text-xs font-semibold">
                    📋 You are currently in **Planning Mode** for Day {simDay + 1}.
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Review your carry-overs above, add additional tasks with the task ledgers, and click Initiate below once ready.
                  </p>
                  <button
                    onClick={handleInitiateNextDay}
                    className="w-full py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 font-extrabold text-xs text-white transition flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-emerald-900/10"
                  >
                    Initiate Day {simDay + 1}
                    <ArrowRight className="h-4 w-4" />
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSendMessage} className="flex gap-2 items-center">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder="Talk to Nudge, or add a task (e.g. 'Add gym by 18:00')..."
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 focus:bg-slate-900 placeholder-slate-500"
                  />
                  
                  {/* Speech-to-Text Microphone button */}
                  <button
                    type="button"
                    onClick={handleToggleListening}
                    title={isListening ? "Listening... click to stop" : "Start Voice Input (Mic)"}
                    className={`p-2.5 rounded-xl transition flex items-center justify-center cursor-pointer relative ${
                      isListening
                        ? 'bg-rose-950/60 border border-rose-500/50 text-rose-400 shadow shadow-rose-950 animate-pulse'
                        : 'bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {isListening ? (
                      <>
                        <MicOff className="h-4 w-4" />
                        <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
                      </>
                    ) : (
                      <Mic className="h-4 w-4" />
                    )}
                  </button>

                  {/* Female TTS Voice Assistant Toggle button */}
                  <button
                    type="button"
                    onClick={() => {
                      const next = !voiceEnabled;
                      setVoiceEnabled(next);
                      setNotification({
                        id: `tts_toggle_${Date.now()}`,
                        title: next ? 'Voice Assistant Active' : 'Voice Assistant Muted',
                        text: next ? 'Female voice touchpoint alerts are now active!' : 'Touchpoint alerts are muted.',
                        type: 'info'
                      });
                      if (next) {
                        speakText("Voice assistant activated.", true);
                      }
                    }}
                    title={voiceEnabled ? "Mute Voice Assistant" : "Enable Voice Assistant"}
                    className={`p-2.5 rounded-xl border transition flex items-center justify-center cursor-pointer ${
                      voiceEnabled
                        ? 'bg-indigo-950/60 border-indigo-500/30 text-indigo-400 hover:text-indigo-300'
                        : 'bg-slate-900 hover:bg-slate-800 border-slate-800 text-slate-500'
                    }`}
                  >
                    {voiceEnabled ? (
                      <Volume2 className="h-4 w-4" />
                    ) : (
                      <VolumeX className="h-4 w-4" />
                    )}
                  </button>

                  <button
                    type="submit"
                    className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white transition flex items-center justify-center cursor-pointer shadow-md shadow-indigo-900/20"
                    aria-label="Send message"
                  >
                    <Send className="h-4 w-4" />
                  </button>
                </form>
              )}
            </div>
          </div>

        </section>

        {/* Right column (40%) - Simulation clocks, configurations, and diagnostics */}
        <section className="lg:col-span-5 flex flex-col gap-6">
          
          {/* Timeline clock simulator component */}
          <TimelineController
            simTime={simTime}
            simDay={simDay}
            autoAdvance={autoAdvance}
            onToggleAutoAdvance={() => setAutoAdvance(!autoAdvance)}
            onAdvanceOneHour={handleAdvanceOneHour}
            onSetTime={handleSetTime}
            workHours={workHours}
            onUpdateWorkHours={(h) => setWorkHours(prev => ({ ...prev, ...h }))}
            onResetSimulation={handleResetSimulation}
            aiStatus={aiStatus}
          />

          {/* AI pattern diagnostics component */}
          <PatternPanel
            history={history}
            aiAnalysis={
              history.length === 0
                ? "Excellent job launching your proactive Nudge schedule. Complete days to enable pattern checking!"
                : history[history.length - 1].aiAnalysis
            }
            suggestedFix={
              history.length > 0 && history[history.length - 1].missedCount > 0
                ? `Move late administrative tasks or routines to mornings instead of Day-End, as energy levels drop after 6:00 PM.`
                : ""
            }
            onApplyFix={handleApplyStructuralFix}
            isFixApplied={false}
            streakCount={streakCount}
          />

          {/* Quick instructions cheat-sheet */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-xs space-y-2">
            <h4 className="font-bold text-slate-300 flex items-center gap-1">
              <CircleAlert className="h-4 w-4 text-amber-400" />
              Nudge Cheat-Sheet
            </h4>
            <p className="text-slate-400 leading-normal">
              Nudge is a **closed-loop planner**. Simulate a full daily cycle:
            </p>
            <ol className="list-decimal pl-4 space-y-1.5 text-slate-400 font-mono text-[10px]">
              <li>Use **Jump to Touchpoint** or **Simulate Day** on the clock board.</li>
              <li>Observe dynamic AI nudges popping up at **12 PM**, **3 PM**, and **6 PM**.</li>
              <li>Wait for **21:30 (9:30 PM)** to experience the interactive **Night Review**.</li>
              <li>Plan carry-overs (urgency auto-upgraded) to progress to the next day!</li>
            </ol>
          </div>

        </section>

      </main>

      {/* Google / Alexa Voice Assistant HUD Overlay */}
      <AnimatePresence>
        {showVoiceHud && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[9999] w-full max-w-md px-4"
          >
            <div className="bg-slate-950/95 border border-cyan-500/30 rounded-2xl p-5 shadow-2xl backdrop-blur-xl ring-4 ring-cyan-500/5 space-y-4">
              
              {/* Header with Glowing LED Status Ring */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="flex gap-1 items-center">
                    <span className={`w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_#22d3ee] ${isListening || isFastVoiceListening ? 'animate-pulse' : ''}`} />
                    <span className={`w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_8px_#3b82f6] ${isListening || isFastVoiceListening ? 'animate-pulse' : ''}`} />
                    <span className={`w-2 h-2 rounded-full bg-purple-500 shadow-[0_0_8px_#a855f7] ${isListening || isFastVoiceListening ? 'animate-pulse' : ''}`} />
                  </div>
                  <span className="text-[11px] font-bold uppercase tracking-widest text-cyan-400 font-mono flex items-center gap-1">
                    <Sparkles className="h-3.5 w-3.5 text-cyan-400" />
                    Alexa Assistant
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    if (isListening && recognitionRef.current) {
                      try { recognitionRef.current.stop(); } catch(e){}
                    }
                    if (isFastVoiceListening && fastVoiceRecognitionRef.current) {
                      try { fastVoiceRecognitionRef.current.stop(); } catch(e){}
                    }
                    setIsListening(false);
                    setIsFastVoiceListening(false);
                    setShowVoiceHud(false);
                    playChime('error');
                  }}
                  className="text-slate-400 hover:text-white text-[10px] font-mono font-bold hover:bg-slate-900 px-2 py-1 rounded cursor-pointer"
                >
                  Dismiss
                </button>
              </div>

              {/* Animated Audio Waveform */}
              {(isListening || isFastVoiceListening) && !voiceHudError && (
                <div className="flex items-center justify-center gap-1.5 h-10 py-2">
                  {[1, 2, 3, 4, 5, 6, 7, 8, 7, 6, 5, 4, 3, 2, 1].map((v, i) => (
                    <span
                      key={i}
                      className="w-1 rounded-full bg-gradient-to-t from-cyan-400 to-indigo-500"
                      style={{
                        height: `${v * 4.5}px`,
                        animation: `wave 1s ease-in-out infinite alternate`,
                        animationDelay: `${i * 0.05}s`
                      }}
                    />
                  ))}
                </div>
              )}

              {/* Transcript / Output display */}
              <div className="space-y-1">
                <p className="text-[9px] uppercase font-mono font-bold text-slate-500">Live Status & Transcript</p>
                <p className={`text-xs font-semibold leading-relaxed ${voiceHudError ? 'text-slate-400' : 'text-slate-100 font-mono bg-slate-900/60 p-3 rounded-lg border border-slate-800'}`}>
                  {voiceHudTranscript || "Listening..."}
                </p>
              </div>

              {/* Microphone Error & Fallback Assistant Input Box */}
              {voiceHudError ? (
                <div className="space-y-3 pt-1">
                  <div className="p-3 bg-rose-950/40 border border-rose-500/20 rounded-xl text-rose-300 text-[11px] leading-relaxed space-y-1 font-mono">
                    <p className="font-bold flex items-center gap-1 text-rose-400">
                      <span>⚠️ Sandbox/Mic Block Alert</span>
                    </p>
                    <p>{voiceHudError}</p>
                  </div>

                  {/* Simulated Voice Typing Form */}
                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono">
                      Type or Select a Voice Command Trigger
                    </label>
                    <form 
                      onSubmit={(e) => {
                        e.preventDefault();
                        const formData = new FormData(e.currentTarget);
                        const target = formData.get('vocalInput') as string;
                        if (!target || !target.trim()) return;
                        
                        if (voiceHudType === 'task') {
                          setShowAddTask(true);
                          setNewTaskName(target);
                          
                          const [hStr, mStr] = simTime.split(':');
                          const h = (parseInt(hStr, 10) + 2) % 24;
                          setNewTaskDeadline(`${String(h).padStart(2, '0')}:${mStr}`);
                          setNewTaskEffort('30m');
                          setNewTaskCategory('URGENT');
                          setFormValidationError(null);
                          
                          playChime('success');
                          speakText(`Adding task: ${target}`, voiceEnabled);
                        } else {
                          setChatInput(target);
                          playChime('success');
                          speakText(`Typed command: ${target}`, voiceEnabled);
                        }
                        setShowVoiceHud(false);
                      }}
                      className="flex gap-2"
                    >
                      <input
                        type="text"
                        name="vocalInput"
                        placeholder={voiceHudType === 'task' ? "e.g. Wash laundry, record budget" : "e.g. Schedule review, what is my streak?"}
                        className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-mono"
                        autoFocus
                      />
                      <button
                        type="submit"
                        className="px-3 bg-cyan-600 hover:bg-cyan-500 text-white font-extrabold text-[11px] rounded-lg transition cursor-pointer"
                      >
                        Execute
                      </button>
                    </form>
                  </div>

                  {/* Popular vocal buttons for ease of test */}
                  <div className="space-y-1">
                    <p className="text-[9px] uppercase font-mono font-bold text-slate-500">Popular Voice Shortcuts</p>
                    <div className="grid grid-cols-2 gap-1.5">
                      {(voiceHudType === 'task' 
                        ? ["Go to gym workout", "Submit budget proposal", "Review physics quiz", "Buy fresh groceries"]
                        : ["Add gym by 18:00", "Review today's agenda", "What is my streak count?", "Show tomorrow's planning"]
                      ).map((preset) => (
                        <button
                          key={preset}
                          type="button"
                          onClick={() => {
                            if (voiceHudType === 'task') {
                              setShowAddTask(true);
                              setNewTaskName(preset);
                              
                              const [hStr, mStr] = simTime.split(':');
                              const h = (parseInt(hStr, 10) + 2) % 24;
                              setNewTaskDeadline(`${String(h).padStart(2, '0')}:${mStr}`);
                              setNewTaskEffort('30m');
                              setNewTaskCategory('URGENT');
                              setFormValidationError(null);
                              
                              playChime('success');
                              speakText(`Adding task: ${preset}`, voiceEnabled);
                            } else {
                              setChatInput(preset);
                              playChime('success');
                              speakText(`Executing command: ${preset}`, voiceEnabled);
                            }
                            setShowVoiceHud(false);
                          }}
                          className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-850 border border-slate-800 rounded-lg text-[10px] text-cyan-300 font-semibold font-mono transition text-left leading-tight hover:border-cyan-500/30 cursor-pointer"
                        >
                          🎙️ "{preset}"
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono">
                  <p className="animate-pulse">🎤 Listening... Speak clearly into your mic</p>
                  <p className="text-cyan-500">Alexa Active</p>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
